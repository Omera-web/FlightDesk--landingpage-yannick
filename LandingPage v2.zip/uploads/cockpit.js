// Cockpit interior — natural luxury, view from BETWEEN/behind the seats looking forward
window.FDCockpit = (function(){
  const {clamp, lerp} = window.FD;

  // ───────── OUT-THE-WINDOW VIEW (kept from natural version) ─────────
  function drawWindowView(ctx, x, y, w, h, t, alpha){
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.clip();

    // sky gradient — high altitude
    const g = ctx.createLinearGradient(x, y, x, y+h);
    g.addColorStop(0, `rgba(8,28,72,${alpha})`);
    g.addColorStop(0.25, `rgba(20,58,118,${alpha})`);
    g.addColorStop(0.55, `rgba(60,120,180,${alpha})`);
    g.addColorStop(0.75, `rgba(140,180,220,${alpha})`);
    g.addColorStop(0.88, `rgba(220,230,240,${alpha})`);
    g.addColorStop(1, `rgba(245,245,245,${alpha})`);
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);

    // sun glint top-right
    const sunX = x + w*0.78, sunY = y + h*0.18;
    const sh = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, h*0.7);
    sh.addColorStop(0, `rgba(255,250,220,${alpha*0.5})`);
    sh.addColorStop(0.15, `rgba(255,240,180,${alpha*0.18})`);
    sh.addColorStop(0.5, `rgba(255,220,140,${alpha*0.04})`);
    sh.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = sh;
    ctx.fillRect(x, y, w, h);
    const sc = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, h*0.08);
    sc.addColorStop(0, `rgba(255,255,250,${alpha})`);
    sc.addColorStop(0.5, `rgba(255,250,230,${alpha*0.7})`);
    sc.addColorStop(1, 'rgba(255,250,230,0)');
    ctx.fillStyle = sc;
    ctx.beginPath(); ctx.arc(sunX, sunY, h*0.08, 0, Math.PI*2); ctx.fill();

    // sea of clouds
    const cloudTop = y + h*0.60;
    const haze = ctx.createLinearGradient(0, cloudTop-h*0.05, 0, y+h);
    haze.addColorStop(0, 'rgba(220,232,242,0)');
    haze.addColorStop(0.2, `rgba(220,232,242,${alpha*0.45})`);
    haze.addColorStop(0.6, `rgba(235,242,250,${alpha*0.85})`);
    haze.addColorStop(1, `rgba(245,248,252,${alpha*0.95})`);
    ctx.fillStyle = haze;
    ctx.fillRect(x, cloudTop-h*0.05, w, h);

    const drift = (t*0.005) % 1;
    for(let i=0;i<28;i++){
      const fi = (i + drift*28) % 28;
      const px = x + ((fi*0.13 + Math.sin(i*9.7)*0.2 + 1) % 1) * w;
      const py = cloudTop + Math.abs(Math.sin(i*5.1))*h*0.32 + i*1.2;
      const pr = h * (0.04 + Math.abs(Math.sin(i*2.7))*0.06);
      ctx.fillStyle = `rgba(150,170,190,${alpha*0.20})`;
      ctx.beginPath();
      ctx.ellipse(px, py+pr*0.5, pr*1.05, pr*0.35, 0, 0, Math.PI*2);
      ctx.fill();
      const cg = ctx.createRadialGradient(px, py-pr*0.15, 0, px, py, pr*1.1);
      cg.addColorStop(0, `rgba(255,253,246,${alpha*0.95})`);
      cg.addColorStop(0.5, `rgba(230,240,250,${alpha*0.7})`);
      cg.addColorStop(1, `rgba(220,232,245,${alpha*0})`);
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.ellipse(px, py, pr*1.15, pr*0.6, 0, 0, Math.PI*2);
      ctx.fill();
      const hgl = ctx.createRadialGradient(px+pr*0.2, py-pr*0.3, 0, px+pr*0.2, py-pr*0.3, pr*0.9);
      hgl.addColorStop(0, `rgba(255,255,250,${alpha*0.55})`);
      hgl.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = hgl;
      ctx.beginPath();
      ctx.ellipse(px+pr*0.2, py-pr*0.25, pr*0.9, pr*0.45, 0, 0, Math.PI*2);
      ctx.fill();
    }

    for(let i=0;i<6;i++){
      const px = x + ((i*0.18 + drift*0.7 + 1) % 1) * w * 1.2 - w*0.1;
      const py = y + h*0.92 + Math.sin(i*3.3)*h*0.04;
      const pr = h*0.4;
      const cg = ctx.createRadialGradient(px, py-pr*0.3, 0, px, py, pr*1.1);
      cg.addColorStop(0, `rgba(255,253,246,${alpha*0.85})`);
      cg.addColorStop(0.55, `rgba(225,235,245,${alpha*0.6})`);
      cg.addColorStop(1, 'rgba(225,235,245,0)');
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.ellipse(px, py, pr*1.3, pr*0.55, 0, 0, Math.PI*2);
      ctx.fill();
    }

    ctx.restore();
  }

  // ───────── PILOT SEAT — 3/4 FRONT VIEW ─────────
  // Substantial captain's chair shown at an angle: we see the cream-leather front
  // (seat-pan + backrest face) clearly, plus the dark outer shell wrapping behind.
  // side: -1 = left seat (turned slightly toward center/right)
  //       +1 = right seat (mirrored)
  function drawSeat(ctx, cx, cy, w, h, alpha, side){
    ctx.save();
    ctx.globalAlpha = alpha;
    if(side > 0){
      // mirror right seat
      ctx.translate(cx, cy);
      ctx.scale(-1, 1);
      ctx.translate(-cx, -cy);
    }

    // === DROP SHADOW
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    ctx.beginPath();
    ctx.ellipse(cx+w*0.04, cy+h*1.04, w*0.55, h*0.07, 0, 0, Math.PI*2);
    ctx.fill();

    // === PEDESTAL / BASE (a low metal plinth)
    ctx.fillStyle = '#0a0c14';
    ctx.beginPath();
    ctx.moveTo(cx-w*0.22, cy+h*0.94);
    ctx.lineTo(cx+w*0.26, cy+h*0.94);
    ctx.lineTo(cx+w*0.32, cy+h*1.04);
    ctx.lineTo(cx-w*0.28, cy+h*1.04);
    ctx.closePath();
    ctx.fill();
    // chrome strip
    ctx.fillStyle = 'rgba(170,178,190,0.55)';
    ctx.fillRect(cx-w*0.24, cy+h*1.000, w*0.56, 1.4);

    // ============================================================
    // Geometry of a captain's chair, turned ~25° to its right.
    // We define key points then fill solid shapes for clarity.
    //
    //   pTL — top of left wing of backrest (closest to camera)
    //   pTR — top of right wing of backrest (farther)
    //   pHL/pHR — left/right of headrest top
    //   bL/bR  — bottom of backrest where it meets cushion
    //   cFL/cFR — front-left / front-right of cushion (closest to camera)
    //   sL/sR  — outer left / outer right of cushion sides
    // ============================================================

    // ── OUTER SHELL (dark) — the back/sides of the chair we glimpse
    // It encloses the cream leather. Drawn first (behind).
    const shellG = ctx.createLinearGradient(cx-w*0.40, cy, cx+w*0.30, cy+h*0.60);
    shellG.addColorStop(0,   '#0a0b11');
    shellG.addColorStop(0.5, '#1a1d28');
    shellG.addColorStop(1,   '#0a0b11');
    ctx.fillStyle = shellG;
    ctx.beginPath();
    // start bottom-left corner of shell (behind cushion side)
    ctx.moveTo(cx-w*0.34, cy+h*0.94);
    // up the LEFT outer flank (the side we see)
    ctx.bezierCurveTo(cx-w*0.42, cy+h*0.78, cx-w*0.44, cy+h*0.35, cx-w*0.36, cy+h*0.05);
    // arc over LEFT shoulder of backrest
    ctx.bezierCurveTo(cx-w*0.32, cy-h*0.08, cx-w*0.18, cy-h*0.14, cx-w*0.04, cy-h*0.14);
    // across top to RIGHT shoulder (foreshortened — narrower)
    ctx.bezierCurveTo(cx+w*0.10, cy-h*0.14, cx+w*0.22, cy-h*0.08, cx+w*0.26, cy+h*0.05);
    // down RIGHT side
    ctx.bezierCurveTo(cx+w*0.30, cy+h*0.35, cx+w*0.28, cy+h*0.66, cx+w*0.24, cy+h*0.74);
    // round to bottom-right of shell (behind cushion)
    ctx.bezierCurveTo(cx+w*0.30, cy+h*0.84, cx+w*0.28, cy+h*0.94, cx+w*0.20, cy+h*0.94);
    ctx.closePath();
    ctx.fill();

    // ── CREAM LEATHER BACKREST (the inside, facing the camera)
    // Big visible panel: this is what makes the seat readable.
    const backG = ctx.createLinearGradient(cx-w*0.28, cy-h*0.08, cx+w*0.22, cy+h*0.65);
    backG.addColorStop(0,   '#cfb594');
    backG.addColorStop(0.35,'#b89870');
    backG.addColorStop(0.75,'#8e7456');
    backG.addColorStop(1,   '#3a2c1c');
    ctx.fillStyle = backG;
    ctx.beginPath();
    // top-left of backrest cushion (under the left shoulder)
    ctx.moveTo(cx-w*0.30, cy);
    // up & over to top-left of headrest area
    ctx.bezierCurveTo(cx-w*0.28, cy-h*0.10, cx-w*0.16, cy-h*0.12, cx-w*0.04, cy-h*0.12);
    // across to top-right (slightly behind / farther)
    ctx.bezierCurveTo(cx+w*0.08, cy-h*0.12, cx+w*0.18, cy-h*0.06, cx+w*0.20, cy+h*0.02);
    // down the right inner edge (where shell meets leather)
    ctx.bezierCurveTo(cx+w*0.24, cy+h*0.30, cx+w*0.22, cy+h*0.58, cx+w*0.18, cy+h*0.66);
    // along the seat-pan join (curving for the seam)
    ctx.bezierCurveTo(cx+w*0.05, cy+h*0.70, cx-w*0.12, cy+h*0.70, cx-w*0.24, cy+h*0.66);
    // up the left inner edge
    ctx.bezierCurveTo(cx-w*0.32, cy+h*0.50, cx-w*0.34, cy+h*0.22, cx-w*0.30, cy);
    ctx.closePath();
    ctx.fill();

    // ── HORIZONTAL QUILT LINES on backrest (capitonné)
    ctx.strokeStyle = 'rgba(50,32,16,0.5)';
    ctx.lineWidth = 1.0;
    for(let i=0;i<6;i++){
      const tt = i/5;
      const py = cy + lerp(-0.06, 0.60, tt) * h;
      // line widens with depth — slight curve
      const xL = cx + lerp(-0.28, -0.26, tt) * w;
      const xR = cx + lerp( 0.18,  0.18, tt) * w;
      ctx.beginPath();
      ctx.moveTo(xL, py);
      ctx.bezierCurveTo(cx-w*0.05, py+1.5, cx+w*0.06, py+1.5, xR, py);
      ctx.stroke();
    }

    // ── DARK CENTER SEAM (faint vertical line on backrest)
    ctx.strokeStyle = 'rgba(50,32,16,0.45)';
    ctx.lineWidth = 0.9;
    ctx.beginPath();
    ctx.moveTo(cx-w*0.02, cy-h*0.08);
    ctx.bezierCurveTo(cx-w*0.04, cy+h*0.20, cx-w*0.04, cy+h*0.45, cx-w*0.04, cy+h*0.65);
    ctx.stroke();

    // ── BACKREST TOP RIM HIGHLIGHT (light catching the leather edge)
    const rimG = ctx.createLinearGradient(cx-w*0.10, cy-h*0.13, cx-w*0.10, cy-h*0.02);
    rimG.addColorStop(0, 'rgba(255,235,200,0.65)');
    rimG.addColorStop(1, 'rgba(255,235,200,0)');
    ctx.fillStyle = rimG;
    ctx.beginPath();
    ctx.moveTo(cx-w*0.28, cy);
    ctx.bezierCurveTo(cx-w*0.26, cy-h*0.10, cx-w*0.14, cy-h*0.13, cx-w*0.02, cy-h*0.13);
    ctx.bezierCurveTo(cx+w*0.10, cy-h*0.13, cx+w*0.18, cy-h*0.07, cx+w*0.20, cy);
    ctx.lineTo(cx+w*0.16, cy+h*0.06);
    ctx.bezierCurveTo(cx+w*0.08, cy-h*0.02, cx-w*0.08, cy-h*0.02, cx-w*0.24, cy+h*0.06);
    ctx.closePath();
    ctx.fill();

    // ── HEADREST PILLOW (slightly proud of the backrest top)
    const headG = ctx.createLinearGradient(cx-w*0.04, cy-h*0.18, cx-w*0.04, cy-h*0.04);
    headG.addColorStop(0, '#d4ba98');
    headG.addColorStop(1, '#9c8268');
    ctx.fillStyle = headG;
    ctx.beginPath();
    ctx.moveTo(cx-w*0.20, cy-h*0.10);
    ctx.bezierCurveTo(cx-w*0.22, cy-h*0.20, cx-w*0.08, cy-h*0.22, cx-w*0.02, cy-h*0.22);
    ctx.bezierCurveTo(cx+w*0.10, cy-h*0.22, cx+w*0.18, cy-h*0.18, cx+w*0.16, cy-h*0.10);
    ctx.bezierCurveTo(cx+w*0.08, cy-h*0.08, cx-w*0.10, cy-h*0.08, cx-w*0.20, cy-h*0.10);
    ctx.closePath();
    ctx.fill();
    // headrest top highlight
    ctx.fillStyle = 'rgba(255,240,210,0.45)';
    ctx.beginPath();
    ctx.ellipse(cx-w*0.02, cy-h*0.19, w*0.09, h*0.018, 0, 0, Math.PI*2);
    ctx.fill();
    // small seam on headrest
    ctx.strokeStyle = 'rgba(50,32,16,0.45)';
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(cx-w*0.18, cy-h*0.11);
    ctx.bezierCurveTo(cx-w*0.06, cy-h*0.13, cx+w*0.04, cy-h*0.13, cx+w*0.14, cy-h*0.11);
    ctx.stroke();

    // ── SEAT CUSHION (top surface, mostly visible — clear pad with thickness)
    // cushion top
    const cushG = ctx.createLinearGradient(cx-w*0.30, cy+h*0.66, cx+w*0.20, cy+h*0.96);
    cushG.addColorStop(0,   '#a89072');
    cushG.addColorStop(0.45,'#d4ba98');
    cushG.addColorStop(1,   '#6c5640');
    ctx.fillStyle = cushG;
    ctx.beginPath();
    // back-left of cushion (touching backrest)
    ctx.moveTo(cx-w*0.26, cy+h*0.66);
    // along seat-back seam
    ctx.bezierCurveTo(cx-w*0.10, cy+h*0.70, cx+w*0.06, cy+h*0.70, cx+w*0.20, cy+h*0.66);
    // round the back-right corner
    ctx.bezierCurveTo(cx+w*0.24, cy+h*0.72, cx+w*0.26, cy+h*0.78, cx+w*0.26, cy+h*0.82);
    // forward to front-right of cushion
    ctx.bezierCurveTo(cx+w*0.26, cy+h*0.90, cx+w*0.18, cy+h*0.94, cx+w*0.08, cy+h*0.94);
    // along front edge
    ctx.bezierCurveTo(cx-w*0.06, cy+h*0.94, cx-w*0.20, cy+h*0.94, cx-w*0.28, cy+h*0.90);
    // up the left side back to start
    ctx.bezierCurveTo(cx-w*0.34, cy+h*0.82, cx-w*0.32, cy+h*0.72, cx-w*0.26, cy+h*0.66);
    ctx.closePath();
    ctx.fill();

    // cushion front edge — darker thickness band (gives volume)
    const cushEdgeG = ctx.createLinearGradient(0, cy+h*0.86, 0, cy+h*0.98);
    cushEdgeG.addColorStop(0, 'rgba(20,12,4,0)');
    cushEdgeG.addColorStop(1, 'rgba(20,12,4,0.55)');
    ctx.fillStyle = cushEdgeG;
    ctx.beginPath();
    ctx.moveTo(cx-w*0.28, cy+h*0.90);
    ctx.bezierCurveTo(cx-w*0.20, cy+h*0.94, cx-w*0.06, cy+h*0.94, cx+w*0.08, cy+h*0.94);
    ctx.bezierCurveTo(cx+w*0.18, cy+h*0.94, cx+w*0.26, cy+h*0.90, cx+w*0.26, cy+h*0.82);
    ctx.lineTo(cx+w*0.26, cy+h*0.94);
    ctx.lineTo(cx-w*0.28, cy+h*0.94);
    ctx.closePath();
    ctx.fill();

    // cushion seam where it meets backrest
    ctx.strokeStyle = 'rgba(40,24,8,0.55)';
    ctx.lineWidth = 1.0;
    ctx.beginPath();
    ctx.moveTo(cx-w*0.26, cy+h*0.66);
    ctx.bezierCurveTo(cx-w*0.10, cy+h*0.70, cx+w*0.06, cy+h*0.70, cx+w*0.20, cy+h*0.66);
    ctx.stroke();

    // cushion top highlight (specular glint where light catches)
    const cushHi = ctx.createLinearGradient(cx, cy+h*0.72, cx+w*0.06, cy+h*0.86);
    cushHi.addColorStop(0, 'rgba(255,240,210,0.55)');
    cushHi.addColorStop(1, 'rgba(255,240,210,0)');
    ctx.fillStyle = cushHi;
    ctx.beginPath();
    ctx.ellipse(cx-w*0.02, cy+h*0.80, w*0.16, h*0.04, -0.1, 0, Math.PI*2);
    ctx.fill();

    // quilted line down center of cushion (matches backrest)
    ctx.strokeStyle = 'rgba(50,32,16,0.40)';
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.moveTo(cx-w*0.04, cy+h*0.70);
    ctx.lineTo(cx-w*0.06, cy+h*0.92);
    ctx.stroke();

    // ── ARMRESTS (one on each side, padded leather)
    // Outer armrest (left of left seat — closer to cabin wall)
    drawArmrest(ctx, cx-w*0.36, cy+h*0.56, w*0.16, h*0.32);
    // Inner armrest (right of left seat — between the seats)
    drawArmrest(ctx, cx+w*0.20, cy+h*0.56, w*0.14, h*0.30);

    // ── 4-POINT HARNESS STRAPS (red) draped from shoulders down
    ctx.strokeStyle = 'rgba(150,40,40,0.85)';
    ctx.lineWidth = 4;
    ctx.lineCap='round';
    // left strap (over left shoulder)
    ctx.beginPath();
    ctx.moveTo(cx-w*0.12, cy-h*0.06);
    ctx.bezierCurveTo(cx-w*0.10, cy+h*0.20, cx-w*0.06, cy+h*0.45, cx-w*0.02, cy+h*0.72);
    ctx.stroke();
    // right strap (over right shoulder, foreshortened)
    ctx.beginPath();
    ctx.moveTo(cx+w*0.06, cy-h*0.06);
    ctx.bezierCurveTo(cx+w*0.08, cy+h*0.20, cx+w*0.06, cy+h*0.45, cx+w*0.02, cy+h*0.72);
    ctx.stroke();
    // strap highlights
    ctx.strokeStyle = 'rgba(220,80,80,0.6)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx-w*0.11, cy-h*0.06);
    ctx.bezierCurveTo(cx-w*0.09, cy+h*0.20, cx-w*0.05, cy+h*0.45, cx-w*0.01, cy+h*0.72);
    ctx.stroke();
    // gold buckle at cushion
    ctx.fillStyle = '#c8a868';
    if(ctx.roundRect){
      ctx.beginPath();
      ctx.roundRect(cx-w*0.04, cy+h*0.74, w*0.08, h*0.025, 2);
      ctx.fill();
    } else {
      ctx.fillRect(cx-w*0.04, cy+h*0.74, w*0.08, h*0.025);
    }
    ctx.strokeStyle = '#5a4628';
    ctx.lineWidth = 0.6;
    ctx.strokeRect(cx-w*0.04, cy+h*0.74, w*0.08, h*0.025);
    ctx.fillStyle = '#5a4628';
    ctx.beginPath();
    ctx.arc(cx, cy+h*0.752, 1.8, 0, Math.PI*2);
    ctx.fill();

    // ── GOLD TRIM PIPING along the outer shell edge (luxury detail)
    ctx.strokeStyle = 'rgba(212,175,110,0.70)';
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(cx-w*0.34, cy+h*0.94);
    ctx.bezierCurveTo(cx-w*0.42, cy+h*0.78, cx-w*0.44, cy+h*0.35, cx-w*0.36, cy+h*0.05);
    ctx.bezierCurveTo(cx-w*0.32, cy-h*0.08, cx-w*0.18, cy-h*0.14, cx-w*0.04, cy-h*0.14);
    ctx.bezierCurveTo(cx+w*0.10, cy-h*0.14, cx+w*0.22, cy-h*0.08, cx+w*0.26, cy+h*0.05);
    ctx.stroke();

    ctx.globalAlpha = 1;
    ctx.restore();
  }

  // Helper: padded leather armrest (drawn at top-left corner ax, ay)
  function drawArmrest(ctx, ax, ay, aw, ah){
    // body
    const armG = ctx.createLinearGradient(ax, ay, ax, ay+ah);
    armG.addColorStop(0,   '#5c4a36');
    armG.addColorStop(0.4, '#7a6248');
    armG.addColorStop(1,   '#2c2014');
    ctx.fillStyle = armG;
    ctx.beginPath();
    ctx.moveTo(ax+aw*0.10, ay);
    ctx.bezierCurveTo(ax+aw*0.40, ay-2, ax+aw*0.70, ay-2, ax+aw*0.95, ay+aw*0.10);
    ctx.lineTo(ax+aw*0.90, ay+ah);
    ctx.bezierCurveTo(ax+aw*0.70, ay+ah+3, ax+aw*0.30, ay+ah+3, ax+aw*0.08, ay+ah);
    ctx.closePath();
    ctx.fill();
    // top highlight (light catches the padded top)
    ctx.fillStyle = 'rgba(255,235,200,0.55)';
    ctx.beginPath();
    ctx.ellipse(ax+aw*0.55, ay+2, aw*0.32, 2.2, 0.05, 0, Math.PI*2);
    ctx.fill();
    // stitch line along top
    ctx.strokeStyle = 'rgba(40,28,14,0.55)';
    ctx.setLineDash([2,2]);
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(ax+aw*0.18, ay+5);
    ctx.bezierCurveTo(ax+aw*0.45, ay+3, ax+aw*0.65, ay+3, ax+aw*0.85, ay+5);
    ctx.stroke();
    ctx.setLineDash([]);
    // chrome adjustment knob on the outer side
    ctx.fillStyle = '#c4c8d0';
    ctx.beginPath();
    ctx.arc(ax+aw*0.55, ay+ah*0.55, 3, 0, Math.PI*2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(40,30,18,0.55)';
    ctx.lineWidth = 0.6;
    ctx.stroke();
  }

  // ───────── GLASS COCKPIT DISPLAYS ─────────
  function drawPFD(ctx, sc, t, alpha){
    const {x, y, w, h} = sc;
    ctx.save();
    ctx.beginPath(); ctx.rect(x,y,w,h); ctx.clip();
    ctx.fillStyle = `rgba(4,6,16,${alpha})`;
    ctx.fillRect(x,y,w,h);
    const ax = x+w*0.55, ay = y+h*0.5, aR = Math.min(w,h)*0.36;
    const pitch = Math.sin(t*0.25)*4;
    const roll = Math.sin(t*0.17)*5;
    const ppx = pitch * (aR/24);
    ctx.save();
    ctx.translate(ax, ay);
    ctx.rotate(roll * Math.PI/180);
    const sky = ctx.createLinearGradient(0,-aR*1.5, 0, ppx);
    sky.addColorStop(0, `rgba(8,52,120,${alpha})`);
    sky.addColorStop(1, `rgba(20,82,160,${alpha})`);
    ctx.fillStyle = sky;
    ctx.fillRect(-aR*2, -aR*2, aR*4, aR*2+ppx);
    const gnd = ctx.createLinearGradient(0, ppx, 0, aR*2);
    gnd.addColorStop(0, `rgba(110,55,15,${alpha})`);
    gnd.addColorStop(1, `rgba(55,28,8,${alpha})`);
    ctx.fillStyle = gnd;
    ctx.fillRect(-aR*2, ppx, aR*4, aR*2);
    ctx.strokeStyle = `rgba(255,255,255,${alpha})`;
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(-aR*2, ppx); ctx.lineTo(aR*2, ppx); ctx.stroke();
    for(let d=-30;d<=30;d+=5){
      if(d===0) continue;
      const ly = ppx - d*(aR/24);
      const ll = (d%10===0?aR*0.35:aR*0.18);
      ctx.strokeStyle = `rgba(255,255,255,${alpha*(d%10===0?0.7:0.4)})`;
      ctx.lineWidth = d%10===0?1.3:0.9;
      ctx.beginPath(); ctx.moveTo(-ll/2, ly); ctx.lineTo(ll/2, ly); ctx.stroke();
    }
    ctx.restore();
    ctx.strokeStyle = `rgba(255,200,40,${alpha})`;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(ax-aR*0.55, ay); ctx.lineTo(ax-aR*0.18, ay);
    ctx.moveTo(ax+aR*0.18, ay); ctx.lineTo(ax+aR*0.55, ay);
    ctx.moveTo(ax-aR*0.04, ay); ctx.lineTo(ax, ay-aR*0.10); ctx.lineTo(ax+aR*0.04, ay);
    ctx.stroke();
    // speed
    const tw = w*0.13;
    ctx.fillStyle = `rgba(8,12,22,${alpha*0.92})`;
    ctx.fillRect(x+w*0.02, y+h*0.18, tw, h*0.64);
    ctx.strokeStyle = `rgba(0,200,255,${alpha*0.4})`;
    ctx.strokeRect(x+w*0.02, y+h*0.18, tw, h*0.64);
    const spd = 482 + Math.round(Math.sin(t*0.3)*3);
    ctx.fillStyle = `rgba(255,255,255,${alpha})`;
    ctx.font = `600 ${Math.round(h*0.13)}px ui-monospace,monospace`;
    ctx.textAlign='center';
    ctx.fillText(spd, x+w*0.02+tw/2, y+h*0.55);
    // alt
    const tx2 = x+w-w*0.02-tw;
    ctx.fillStyle = `rgba(8,12,22,${alpha*0.92})`;
    ctx.fillRect(tx2, y+h*0.18, tw, h*0.64);
    ctx.strokeStyle = `rgba(0,200,255,${alpha*0.4})`;
    ctx.strokeRect(tx2, y+h*0.18, tw, h*0.64);
    const alt = 41000 + Math.round(Math.sin(t*0.19)*30);
    ctx.fillStyle = `rgba(255,255,255,${alpha})`;
    ctx.font = `600 ${Math.round(h*0.10)}px ui-monospace,monospace`;
    ctx.fillText(alt, tx2+tw/2, y+h*0.55);
    ctx.fillStyle = `rgba(0,200,255,${alpha*0.9})`;
    ctx.font = `600 ${Math.round(h*0.08)}px ui-monospace,monospace`;
    ctx.fillText('HDG 284°', ax, y+h*0.95);
    ctx.restore();
  }

  function drawMFD(ctx, sc, t, alpha){
    const {x, y, w, h} = sc;
    ctx.save();
    ctx.beginPath(); ctx.rect(x,y,w,h); ctx.clip();
    ctx.fillStyle = `rgba(6,10,18,${alpha})`;
    ctx.fillRect(x,y,w,h);
    const mg = ctx.createRadialGradient(x+w/2, y+h*0.55, 0, x+w/2, y+h*0.55, h*0.6);
    mg.addColorStop(0, `rgba(18,30,55,${alpha})`);
    mg.addColorStop(1, `rgba(6,10,20,${alpha})`);
    ctx.fillStyle = mg;
    ctx.fillRect(x, y+h*0.15, w, h*0.85);
    ctx.strokeStyle = `rgba(120,180,255,${alpha*0.18})`;
    ctx.lineWidth = 0.8;
    for(let i=1;i<=4;i++){
      ctx.beginPath();
      ctx.arc(x+w/2, y+h*0.82, h*0.16*i, -Math.PI*0.75, -Math.PI*0.25);
      ctx.stroke();
    }
    ctx.strokeStyle = `rgba(180,140,255,${alpha*0.85})`;
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    ctx.moveTo(x+w/2, y+h*0.82);
    ctx.lineTo(x+w*0.62, y+h*0.45);
    ctx.lineTo(x+w*0.85, y+h*0.30);
    ctx.stroke();
    ctx.setLineDash([]);
    [
      {wx: w*0.62, wy: h*0.45, n: 'KESLA'},
      {wx: w*0.85, wy: h*0.30, n: 'BIKAR'},
      {wx: w*0.30, wy: h*0.60, n: 'ROMEO'},
    ].forEach(p=>{
      ctx.fillStyle = `rgba(180,140,255,${alpha})`;
      ctx.beginPath(); ctx.arc(x+p.wx, y+p.wy, 3, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = `rgba(220,210,255,${alpha*0.85})`;
      ctx.font = `500 ${Math.round(h*0.06)}px ui-monospace,monospace`;
      ctx.textAlign='left';
      ctx.fillText(p.n, x+p.wx+6, y+p.wy+3);
    });
    ctx.fillStyle = `rgba(255,240,80,${alpha})`;
    ctx.beginPath();
    ctx.moveTo(x+w/2, y+h*0.78);
    ctx.lineTo(x+w/2-7, y+h*0.86);
    ctx.lineTo(x+w/2+7, y+h*0.86);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = `rgba(180,140,255,${alpha*0.85})`;
    ctx.font = `600 ${Math.round(h*0.085)}px ui-monospace,monospace`;
    ctx.textAlign='left';
    ctx.fillText('MAP · NAV', x+w*0.04, y+h*0.10);
    const items = [['DTG','1142 NM'],['ETE','02:24'],['ETA','14:38Z'],['GS','512 KT']];
    items.forEach(([l,v],i)=>{
      const ry = y+h*0.96-i*h*0.06;
      ctx.fillStyle = `rgba(180,140,255,${alpha*0.6})`;
      ctx.font = `${Math.round(h*0.058)}px ui-monospace,monospace`;
      ctx.textAlign='left'; ctx.fillText(l, x+w*0.04, ry);
      ctx.fillStyle = `rgba(220,210,255,${alpha})`;
      ctx.textAlign='right'; ctx.fillText(v, x+w*0.55, ry);
    });
    ctx.restore();
  }

  function drawEICAS(ctx, sc, t, alpha){
    const {x, y, w, h} = sc;
    ctx.save();
    ctx.beginPath(); ctx.rect(x,y,w,h); ctx.clip();
    ctx.fillStyle = `rgba(4,6,16,${alpha})`;
    ctx.fillRect(x,y,w,h);
    ctx.fillStyle = `rgba(80,220,160,${alpha*0.9})`;
    ctx.font = `600 ${Math.round(h*0.085)}px ui-monospace,monospace`;
    ctx.textAlign='left';
    ctx.fillText('EICAS', x+w*0.04, y+h*0.10);
    [0,1].forEach(i=>{
      const cx = x + w*(0.30 + i*0.40);
      const cy = y + h*0.42;
      const r = h*0.20;
      const n1 = 92.4 + Math.sin(t*0.35 + i)*1.3;
      ctx.strokeStyle = `rgba(40,70,90,${alpha*0.9})`;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(cx, cy, r, Math.PI*0.75, Math.PI*2.25);
      ctx.stroke();
      ctx.strokeStyle = `rgba(80,220,160,${alpha})`;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(cx, cy, r, Math.PI*0.75, Math.PI*0.75 + (n1/100)*Math.PI*1.5);
      ctx.stroke();
      ctx.fillStyle = `rgba(255,255,255,${alpha})`;
      ctx.font = `700 ${Math.round(h*0.12)}px ui-monospace,monospace`;
      ctx.textAlign='center';
      ctx.fillText(n1.toFixed(1), cx, cy+3);
      ctx.fillStyle = `rgba(80,220,160,${alpha*0.7})`;
      ctx.font = `${Math.round(h*0.065)}px ui-monospace,monospace`;
      ctx.fillText('N1 ENG '+(i+1), cx, cy+r+h*0.06);
    });
    const rows = [
      ['ITT',  '742°C', '255,200,40'],
      ['FF',   '2950 lb/h', '0,200,255'],
      ['OIL',  '74 PSI', '80,220,160'],
      ['FUEL', '14 200 lb', '0,200,255'],
    ];
    rows.forEach(([l,v,c],i)=>{
      const ry = y + h*0.75 + (i%2)*h*0.11;
      const col = i<2 ? 0 : 1;
      const lx = x + w*(0.10 + col*0.48);
      ctx.fillStyle = `rgba(${c},${alpha*0.6})`;
      ctx.font = `${Math.round(h*0.062)}px ui-monospace,monospace`;
      ctx.textAlign='left'; ctx.fillText(l, lx, ry);
      ctx.fillStyle = `rgba(${c},${alpha*0.95})`;
      ctx.textAlign='right'; ctx.fillText(v, lx+w*0.35, ry);
    });
    ctx.restore();
  }

  // ───────── MAIN ─────────
  function drawCockpitInterior(ctx, W, H, t, alpha){
    const a = clamp(alpha, 0, 1);

    // base
    ctx.fillStyle = `rgba(8,10,16,${a})`;
    ctx.fillRect(0, 0, W, H);

    // Geometry
    const winY = H*0.05, winH = H*0.50;
    const winLeftTop = W*0.13, winRightTop = W*0.87;
    const winLeftBot = W*0.07, winRightBot = W*0.93;

    // === Windscreen — realistic view, panoramic
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(winLeftBot, winY+winH);
    ctx.lineTo(winLeftTop, winY+H*0.005);
    ctx.bezierCurveTo(W*0.30, winY-H*0.02, W*0.70, winY-H*0.02, winRightTop, winY+H*0.005);
    ctx.lineTo(winRightBot, winY+winH);
    ctx.closePath();
    ctx.clip();
    drawWindowView(ctx, 0, 0, W, H*0.80, t, a);
    ctx.restore();

    // windscreen rim subtle highlight
    ctx.strokeStyle = `rgba(180,200,225,${a*0.40})`;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(winLeftBot, winY+winH);
    ctx.lineTo(winLeftTop, winY+H*0.005);
    ctx.bezierCurveTo(W*0.30, winY-H*0.02, W*0.70, winY-H*0.02, winRightTop, winY+H*0.005);
    ctx.lineTo(winRightBot, winY+winH);
    ctx.stroke();

    // === A-pillars (side posts)
    const postG = ctx.createLinearGradient(0,0,W*0.06,0);
    postG.addColorStop(0, `rgba(20,22,30,${a})`);
    postG.addColorStop(1, `rgba(38,42,52,${a})`);
    ctx.fillStyle = postG;
    ctx.beginPath();
    ctx.moveTo(0,0); ctx.lineTo(winLeftTop, winY+H*0.005);
    ctx.lineTo(winLeftBot, winY+winH);
    ctx.lineTo(0, winY+winH+H*0.04);
    ctx.closePath(); ctx.fill();
    const postG2 = ctx.createLinearGradient(W*0.94,0,W,0);
    postG2.addColorStop(0, `rgba(38,42,52,${a})`);
    postG2.addColorStop(1, `rgba(20,22,30,${a})`);
    ctx.fillStyle = postG2;
    ctx.beginPath();
    ctx.moveTo(W,0); ctx.lineTo(winRightTop, winY+H*0.005);
    ctx.lineTo(winRightBot, winY+winH);
    ctx.lineTo(W, winY+winH+H*0.04);
    ctx.closePath(); ctx.fill();

    // central thin pillar
    ctx.fillStyle = `rgba(20,22,30,${a*0.95})`;
    const cpW = W*0.005;
    ctx.fillRect(W/2-cpW, winY+H*0.005, cpW*2, winH-H*0.005);

    // === Glareshield (top hood above dashboard)
    const ghY = winY + winH;
    const gsG = ctx.createLinearGradient(0, ghY-H*0.03, 0, ghY+H*0.03);
    gsG.addColorStop(0, `rgba(8,10,16,0)`);
    gsG.addColorStop(0.4, `rgba(14,16,22,${a*0.85})`);
    gsG.addColorStop(1, `rgba(20,22,30,${a})`);
    ctx.fillStyle = gsG;
    ctx.beginPath();
    ctx.moveTo(0, ghY-H*0.005);
    ctx.bezierCurveTo(W*0.3, ghY+H*0.018, W*0.7, ghY+H*0.018, W, ghY-H*0.005);
    ctx.lineTo(W, ghY+H*0.035);
    ctx.lineTo(0, ghY+H*0.035);
    ctx.closePath();
    ctx.fill();
    // glareshield stitching
    ctx.strokeStyle = `rgba(180,150,100,${a*0.40})`;
    ctx.setLineDash([4,3]); ctx.lineWidth=0.7;
    ctx.beginPath();
    ctx.moveTo(0, ghY+H*0.020);
    ctx.bezierCurveTo(W*0.3, ghY+H*0.030, W*0.7, ghY+H*0.030, W, ghY+H*0.020);
    ctx.stroke();
    ctx.setLineDash([]);

    // === Dashboard body
    const dashY = ghY + H*0.035;
    const dashG = ctx.createLinearGradient(0, dashY, 0, H);
    dashG.addColorStop(0, `rgba(22,24,32,${a})`);
    dashG.addColorStop(0.15, `rgba(28,30,38,${a})`);
    dashG.addColorStop(1, `rgba(10,12,18,${a})`);
    ctx.fillStyle = dashG;
    ctx.fillRect(0, dashY, W, H);

    // subtle stipple grain
    ctx.fillStyle = `rgba(255,255,255,${a*0.018})`;
    for(let i=0;i<400;i++){
      const px = (i*173) % W;
      const py = dashY + ((i*97) % (H-dashY));
      ctx.fillRect(px, py, 1, 1);
    }

    // === Three displays
    const sY = dashY + H*0.012;
    const sH = H*0.20;
    const gap = W*0.012;
    const sW = (W - gap*4) / 3;
    const screens = [
      {x: gap,            y: sY, w: sW, h: sH, type:'pfd', c:[120,190,255], label:'PFD'},
      {x: gap*2+sW,       y: sY, w: sW, h: sH, type:'mfd', c:[180,140,255], label:'MFD · NAV'},
      {x: gap*3+sW*2,     y: sY, w: sW, h: sH, type:'eicas', c:[80,220,160], label:'EICAS'}
    ];
    screens.forEach(s=>{
      const [r,g,b] = s.c;
      // bezel
      ctx.fillStyle = `rgba(6,8,14,${a})`;
      ctx.fillRect(s.x-3, s.y-3, s.w+6, s.h+6);
      ctx.strokeStyle = `rgba(70,78,92,${a*0.7})`;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(s.x-3, s.y-3, s.w+6, s.h+6);
      // header band
      ctx.fillStyle = `rgba(4,6,16,${a*0.98})`;
      ctx.fillRect(s.x, s.y, s.w, s.h);
      ctx.fillStyle = `rgba(${r},${g},${b},${a*0.10})`;
      ctx.fillRect(s.x, s.y, s.w, s.h*0.10);
      ctx.fillStyle = `rgba(${r},${g},${b},${a*0.9})`;
      ctx.font = `600 ${Math.round(s.h*0.075)}px ui-monospace,monospace`;
      ctx.textAlign='left';
      ctx.fillText(s.label, s.x+8, s.y+s.h*0.078);
      ctx.textAlign='right';
      ctx.fillStyle = `rgba(${r},${g},${b},${a*0.6})`;
      ctx.fillText('14:27Z', s.x+s.w-8, s.y+s.h*0.078);
      // content
      ctx.save();
      ctx.beginPath(); ctx.rect(s.x, s.y+s.h*0.11, s.w, s.h*0.89); ctx.clip();
      const sc2 = {x:s.x, y:s.y+s.h*0.11, w:s.w, h:s.h*0.89};
      if(s.type==='pfd') drawPFD(ctx, sc2, t, a);
      if(s.type==='mfd') drawMFD(ctx, sc2, t, a);
      if(s.type==='eicas') drawEICAS(ctx, sc2, t, a);
      ctx.restore();
      // sheen
      const gr = ctx.createLinearGradient(s.x, s.y, s.x+s.w, s.y+s.h);
      gr.addColorStop(0, `rgba(255,255,255,${a*0.04})`);
      gr.addColorStop(0.3, 'rgba(255,255,255,0)');
      ctx.fillStyle = gr;
      ctx.fillRect(s.x, s.y, s.w, s.h);
    });

    // === Center pedestal with throttles
    const pedTopY = sY + sH + H*0.005;
    const pX = W/2;
    const pedG = ctx.createLinearGradient(pX-W*0.06, pedTopY, pX+W*0.06, pedTopY);
    pedG.addColorStop(0, `rgba(12,14,22,${a})`);
    pedG.addColorStop(0.5, `rgba(22,26,38,${a})`);
    pedG.addColorStop(1, `rgba(12,14,22,${a})`);
    ctx.fillStyle = pedG;
    ctx.beginPath();
    ctx.moveTo(pX-W*0.055, pedTopY);
    ctx.bezierCurveTo(pX-W*0.065, pedTopY+H*0.08, pX-W*0.07, H*0.84, pX-W*0.068, H);
    ctx.lineTo(pX+W*0.068, H);
    ctx.bezierCurveTo(pX+W*0.07, H*0.84, pX+W*0.065, pedTopY+H*0.08, pX+W*0.055, pedTopY);
    ctx.closePath();
    ctx.fill();
    // throttles
    [-1,1].forEach(side=>{
      const tx = pX + side*W*0.022;
      const ty = pedTopY + H*0.020;
      ctx.fillStyle = `rgba(40,46,60,${a})`;
      ctx.beginPath();
      if(ctx.roundRect) ctx.roundRect(tx-5, ty, 10, H*0.08, 3);
      else ctx.rect(tx-5, ty, 10, H*0.08);
      ctx.fill();
      const tg = ctx.createRadialGradient(tx, ty-2, 0, tx, ty-2, 10);
      tg.addColorStop(0, `rgba(232,201,122,${a})`);
      tg.addColorStop(0.55, `rgba(180,142,72,${a})`);
      tg.addColorStop(1, `rgba(80,56,18,${a})`);
      ctx.fillStyle = tg;
      ctx.beginPath();
      ctx.ellipse(tx, ty, 7, 5, 0, 0, Math.PI*2); ctx.fill();
    });
    // radio LCD
    ctx.fillStyle = `rgba(4,6,12,${a})`;
    ctx.fillRect(pX-W*0.026, pedTopY+H*0.115, W*0.052, H*0.030);
    ctx.fillStyle = `rgba(0,200,255,${a*0.95})`;
    ctx.font = `600 ${Math.round(H*0.020)}px ui-monospace,monospace`;
    ctx.textAlign='center';
    ctx.fillText('118.500', pX, pedTopY+H*0.135);
    // LEDs
    for(let i=0;i<5;i++){
      ctx.fillStyle = i%2 ? `rgba(80,220,140,${a*0.75})` : `rgba(255,200,40,${a*0.75})`;
      ctx.beginPath();
      ctx.arc(pX-W*0.024+i*W*0.012, pedTopY+H*0.165, 1.6, 0, Math.PI*2);
      ctx.fill();
    }

    // === TWO SEATS — 3/4 front view (see front of seats)
    // place them at lower-foreground left & right corners, larger than before
    const seatW = W*0.30, seatH = H*0.46;
    // The function expects (cx, cy) — the central top-of-seat anchor.
    drawSeat(ctx, W*0.18, H*0.42, seatW, seatH, a, -1);   // left seat, turned toward right
    drawSeat(ctx, W*0.82, H*0.42, seatW, seatH, a, 1);    // right seat, turned toward left

    // === Subtle ambient warm light from windscreen onto dashboard
    const wlight = ctx.createLinearGradient(0, winY+winH*0.6, 0, dashY+H*0.06);
    wlight.addColorStop(0, `rgba(255,225,180,${a*0.05})`);
    wlight.addColorStop(1, 'rgba(255,225,180,0)');
    ctx.fillStyle = wlight;
    ctx.fillRect(0, winY+winH*0.6, W, H*0.12);

    // === Vignette
    const vig = ctx.createRadialGradient(W/2, H*0.45, H*0.20, W/2, H*0.45, H*1.05);
    vig.addColorStop(0, 'rgba(0,0,0,0)');
    vig.addColorStop(0.55, 'rgba(0,0,0,0)');
    vig.addColorStop(1, `rgba(0,0,0,${a*0.88})`);
    ctx.fillStyle = vig;
    ctx.fillRect(0, 0, W, H);
  }

  return {drawCockpitInterior};
})();
