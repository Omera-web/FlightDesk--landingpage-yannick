// Realistic sky + volumetric clouds + sun
window.FDSky = (function(){
  const {clamp, lerp, rnd, fbm, smoothstep} = window.FD;

  // multi-layer cloud field — 3 altitudes
  // layer 0 = low cumulus (foreground), 1 = mid, 2 = high cirrus
  const cloudCache = {};

  // Generate procedural puffy cloud sprite to offscreen canvas (cached)
  function makeCloudSprite(seed, w, h, sunDir){
    const key = `${seed}_${w}_${h}_${sunDir.toFixed(2)}`;
    if(cloudCache[key]) return cloudCache[key];
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const x = c.getContext('2d');
    // puff positions — tightly constrained within canvas with padding
    const puffN = 12 + Math.floor(rnd(seed*7.3)*8);
    const cx = w/2, cy = h*0.55;
    const padX = w*0.20;     // keep puffs inside this margin
    const padY = h*0.30;
    const maxR = Math.min(padX, padY) * 0.9;
    const puffs = [];
    for(let i=0;i<puffN;i++){
      const ang = rnd(seed*13.1+i*1.7) * Math.PI * 2;
      const rad = (0.15 + rnd(seed*7.3+i*3.1)*0.55) * (Math.min(w,h*2)*0.18);
      const pX = clamp(cx + Math.cos(ang) * rad, padX*1.1, w-padX*1.1);
      const pY = clamp(cy + Math.sin(ang) * rad * 0.55, padY*0.5, h-padY*0.6);
      const pR = clamp((0.06 + rnd(seed*5.5+i*2.3)*0.10) * w, 12, maxR);
      puffs.push({x:pX, y:pY, r:pR});
    }
    // sort by y (back to front)
    puffs.sort((a,b)=>a.y-b.y);

    // 1st pass — soft shadow body
    puffs.forEach(p=>{
      const g = x.createRadialGradient(p.x, p.y+p.r*0.3, 0, p.x, p.y+p.r*0.3, p.r*1.3);
      g.addColorStop(0,'rgba(70,82,108,0.40)');
      g.addColorStop(0.5,'rgba(80,92,118,0.20)');
      g.addColorStop(1,'rgba(80,92,118,0)');
      x.fillStyle = g;
      x.beginPath(); x.arc(p.x, p.y+p.r*0.25, p.r*1.3, 0, Math.PI*2); x.fill();
    });

    // 2nd pass — body (mid tone)
    puffs.forEach(p=>{
      const g = x.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r);
      g.addColorStop(0,'rgba(238,242,248,0.96)');
      g.addColorStop(0.45,'rgba(220,228,240,0.85)');
      g.addColorStop(0.78,'rgba(195,210,228,0.45)');
      g.addColorStop(1,'rgba(195,210,228,0)');
      x.fillStyle = g;
      x.beginPath(); x.arc(p.x, p.y, p.r, 0, Math.PI*2); x.fill();
    });

    // 3rd pass — top highlight (sun-lit)
    const sX = Math.cos(sunDir) * 0.35;
    const sY = -Math.abs(Math.sin(sunDir)) * 0.45;
    puffs.forEach(p=>{
      const hx = p.x + p.r*sX, hy = p.y + p.r*sY;
      const g = x.createRadialGradient(hx, hy, 0, hx, hy, p.r*0.85);
      g.addColorStop(0,'rgba(255,253,246,0.85)');
      g.addColorStop(0.5,'rgba(252,247,232,0.45)');
      g.addColorStop(1,'rgba(252,247,232,0)');
      x.fillStyle = g;
      x.beginPath(); x.arc(hx, hy, p.r*0.85, 0, Math.PI*2); x.fill();
    });

    cloudCache[key] = c;
    return c;
  }


  // High-altitude cirrus streaks — soft, atmospheric
  function drawCirrus(ctx, W, H, t){
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for(let i=0;i<5;i++){
      const y = H*(0.08 + i*0.04) + Math.sin(t*0.05 + i)*4;
      const x = (i*W*0.22 + t*6) % (W*1.4) - W*0.2;
      const w = W*0.55 + rnd(i*3.1)*W*0.3;
      const h = 3 + rnd(i*7.7)*5;
      const g = ctx.createLinearGradient(x, y, x+w, y);
      g.addColorStop(0, 'rgba(255,255,255,0)');
      g.addColorStop(0.5, `rgba(255,255,255,${0.05 + rnd(i)*0.04})`);
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(x+w/2, y, w/2, h, 0, 0, Math.PI*2);
      ctx.fill();
    }
    ctx.restore();
  }

  // Sky gradient — atmospheric scattering style (top deep blue, horizon pale)
  function drawSkyGradient(ctx, W, H, sunY){
    const g = ctx.createLinearGradient(0, 0, 0, H);
    // upper atmosphere - deep navy
    g.addColorStop(0.00, '#0a1a3a');
    g.addColorStop(0.10, '#143467');
    g.addColorStop(0.25, '#1d5394');
    g.addColorStop(0.45, '#3079bd');
    g.addColorStop(0.65, '#5fa3d8');
    g.addColorStop(0.80, '#9fc8e8');
    g.addColorStop(0.92, '#d2e4f0');
    g.addColorStop(1.00, '#e8eef2');
    ctx.fillStyle = g;
    ctx.fillRect(0,0,W,H);
  }

  // Sun + glare — bright, photographic
  function drawSun(ctx, W, H, sX, sY){
    // ambient atmospheric glow (very wide)
    const amb = ctx.createRadialGradient(sX, sY, 0, sX, sY, H*1.1);
    amb.addColorStop(0, 'rgba(255,250,225,0.32)');
    amb.addColorStop(0.15, 'rgba(255,240,200,0.18)');
    amb.addColorStop(0.4, 'rgba(255,225,150,0.06)');
    amb.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = amb;
    ctx.fillRect(0,0,W,H);
    // mid halo
    const halo = ctx.createRadialGradient(sX, sY, 0, sX, sY, H*0.32);
    halo.addColorStop(0, 'rgba(255,250,225,0.95)');
    halo.addColorStop(0.08, 'rgba(255,245,200,0.75)');
    halo.addColorStop(0.25, 'rgba(255,235,160,0.25)');
    halo.addColorStop(0.55, 'rgba(255,220,120,0.06)');
    halo.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = halo;
    ctx.fillRect(0,0,W,H);
    // bright core
    const core = ctx.createRadialGradient(sX, sY, 0, sX, sY, H*0.07);
    core.addColorStop(0, 'rgba(255,255,250,1)');
    core.addColorStop(0.4, 'rgba(255,250,225,0.95)');
    core.addColorStop(0.8, 'rgba(255,235,170,0.5)');
    core.addColorStop(1, 'rgba(255,230,150,0)');
    ctx.fillStyle = core;
    ctx.beginPath(); ctx.arc(sX, sY, H*0.07, 0, Math.PI*2); ctx.fill();
    // disk
    ctx.fillStyle = 'rgba(255,255,250,0.98)';
    ctx.beginPath(); ctx.arc(sX, sY, H*0.018, 0, Math.PI*2); ctx.fill();
    // lens flare streaks
    ctx.save();
    ctx.translate(sX, sY);
    ctx.globalCompositeOperation = 'screen';
    for(let i=0;i<6;i++){
      const ang = i * Math.PI/3;
      const len = H*0.18;
      const sg = ctx.createLinearGradient(0,0, Math.cos(ang)*len, Math.sin(ang)*len);
      sg.addColorStop(0, 'rgba(255,245,200,0.65)');
      sg.addColorStop(1, 'rgba(255,245,200,0)');
      ctx.strokeStyle = sg;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0,0);
      ctx.lineTo(Math.cos(ang)*len, Math.sin(ang)*len);
      ctx.stroke();
    }
    ctx.restore();
  }

  return {makeCloudSprite, drawCirrus, drawSkyGradient, drawSun};
})();
