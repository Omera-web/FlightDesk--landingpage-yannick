// Main animation loop
(function(){
  const {clamp, ease, easeOut, easeIn, smoothstep} = window.FD;
  const cv = document.getElementById('cv');
  const ctx = cv.getContext('2d');
  const hud = document.getElementById('hud');
  const tm = document.getElementById('tm');
  const pp = document.getElementById('pp');

  // High-DPI scaling
  let W, H, DPR = window.devicePixelRatio || 1;
  function resize(){
    const r = cv.getBoundingClientRect();
    if(r.width < 10) return;
    W = r.width; H = r.height || (W*9/16);
    cv.width = Math.round(W * DPR);
    cv.height = Math.round(H * DPR);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }
  resize();
  window.addEventListener('resize', resize);
  window.addEventListener('load', resize);
  // Use ResizeObserver for container size changes
  if(window.ResizeObserver){
    const ro = new ResizeObserver(resize);
    ro.observe(cv);
  }
  // also schedule a few delayed resizes to catch late layout
  [50, 150, 500, 1200].forEach(d => setTimeout(resize, d));

  // Timeline
  const PHASES = [
    {name: 'EXTERIOR — CRUISE',     dur: 4.5},
    {name: 'APPROACH — ZOOM IN',    dur: 3.0},
    {name: 'COCKPIT — INTERIOR',    dur: 5.0},
    {name: 'FADE OUT — EXTERIOR',   dur: 2.0},
  ];
  const TOTAL = PHASES.reduce((a,p)=>a+p.dur, 0);

  let t = 0, paused = false, lastTs = 0;

  // restore from localStorage
  try {
    const saved = parseFloat(localStorage.getItem('jetAnim_t'));
    if(!isNaN(saved)) t = saved;
  } catch(e){}

  function fmt(s){
    const m = Math.floor(s/60), ss = Math.floor(s%60);
    return `${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
  }

  function getPhase(time){
    let acc = 0;
    for(let i=0;i<PHASES.length;i++){
      if(time < acc + PHASES[i].dur){
        return {idx:i, p:(time-acc)/PHASES[i].dur, name: PHASES[i].name};
      }
      acc += PHASES[i].dur;
    }
    return {idx: PHASES.length-1, p: 1, name: PHASES[PHASES.length-1].name};
  }

  function draw(){
    ctx.clearRect(0,0,W,H);
    const time = t % TOTAL;
    const ph = getPhase(time);

    if(ph.idx === 0){
      // === EXTERIOR CRUISE ===
      drawExteriorScene(time, 1, 1);
    }
    else if(ph.idx === 1){
      // === ZOOM IN to cockpit ===
      const p = ph.p;
      const ep = ease(p);
      // exterior fades & zooms in toward jet cockpit window
      const exteriorAlpha = clamp(1 - ep*1.4, 0, 1);
      const zoomScale = 1 + ep*8;     // dramatic zoom into the jet's cockpit window
      drawExteriorScene(time, exteriorAlpha, zoomScale);
      // dark transition vignette
      const transAlpha = clamp((ep-0.35)/0.4, 0, 1);
      const vig = ctx.createRadialGradient(W/2, H*0.42, H*(0.45 - ep*0.35), W/2, H*0.42, H*0.95);
      vig.addColorStop(0, 'rgba(0,0,0,0)');
      vig.addColorStop(0.5, `rgba(4,8,16,${ep*0.5})`);
      vig.addColorStop(1, `rgba(4,8,16,${ep*0.95})`);
      ctx.fillStyle = vig;
      ctx.fillRect(0,0,W,H);
      // cockpit fades in
      const cockpitA = clamp((ep-0.55)/0.45, 0, 1);
      if(cockpitA > 0){
        FDCockpit.drawCockpitInterior(ctx, W, H, time, cockpitA);
      }
    }
    else if(ph.idx === 2){
      // === COCKPIT INTERIOR ===
      FDCockpit.drawCockpitInterior(ctx, W, H, time, 1);
    }
    else {
      // === FADE OUT to exterior ===
      const p = ph.p;
      const ep = ease(p);
      // exterior fades in
      drawExteriorScene(time, ep, 1 + (1-ep)*4);
      // cockpit fades out
      const cA = clamp(1 - ep/0.7, 0, 1);
      if(cA > 0){
        FDCockpit.drawCockpitInterior(ctx, W, H, time, cA);
      }
    }

    // film grain (subtle, always)
    addGrain(0.04);

    // letterbox subtle on top/bottom for cinematic feel
    ctx.fillStyle = 'rgba(0,0,0,0.85)';
    ctx.fillRect(0, 0, W, H*0.022);
    ctx.fillRect(0, H*0.978, W, H*0.022);

    // HUD
    hud.textContent = ph.name;
    tm.textContent = `${fmt(time)} / ${fmt(TOTAL)}`;
  }

  function drawExteriorScene(time, alpha, zoomScale){
    ctx.save();
    ctx.globalAlpha = alpha;
    if(zoomScale !== 1){
      // zoom into the jet cockpit area
      const cx = W*0.42; // jet cockpit is left of center
      const cy = H*0.42;
      ctx.translate(W/2, H/2);
      ctx.scale(zoomScale, zoomScale);
      ctx.translate(-cx, -cy);
    }

    // sky
    FDSky.drawSkyGradient(ctx, W, H, H*0.18);
    // sun glow
    FDSky.drawSun(ctx, W, H, W*0.78, H*0.18);
    // high cirrus
    FDSky.drawCirrus(ctx, W, H, time);

    // earth far below
    FDEarth.drawEarth(ctx, W, H, time);

    // mid + far cloud layer (above earth, below us)
    drawCloudLayer(time);

    // the jet
    const sc = Math.min(W, H*16/9) / 1600;
    const baseSc = 0.55 * sc;
    const breathe = 1 + Math.sin(time*0.6)*0.008;
    const jx = W*0.50 + Math.sin(time*0.18)*W*0.012;
    const jy = H*0.42 + Math.sin(time*0.22)*H*0.018;
    const bank = Math.sin(time*0.25)*0.04;
    FDJet.drawJet(ctx, jx, jy, baseSc*breathe, 1, time, bank);

    // foreground clouds (we're flying above them) for parallax
    drawForegroundClouds(time);

    ctx.restore();
  }

  // === multi-layer parallax cloud field ===
  const cloudLayer = [];
  for(let i=0;i<14;i++){
    cloudLayer.push({
      seed: i*7.3 + 1,
      x: Math.random(),
      y: 0.62 + Math.random()*0.14,
      scale: 0.5 + Math.random()*0.7,
      speed: 0.0015 + Math.random()*0.003,
      altitude: Math.random() // 0=close, 1=far
    });
  }
  const fgClouds = [];
  for(let i=0;i<3;i++){
    fgClouds.push({
      seed: 100 + i*5.7,
      x: Math.random()*1.4 - 0.2,
      y: 0.84 + Math.random()*0.06,
      scale: 0.7 + Math.random()*0.4,
      speed: 0.014 + Math.random()*0.010
    });
  }

  function drawCloudLayer(time){
    cloudLayer.forEach(c=>{
      c.x = (c.x + c.speed * 0.016) % 1.2;
      const cx = c.x * W * 1.2 - W*0.1;
      const cy = c.y * H;
      const cw = W * 0.18 * c.scale;
      const ch = cw * 0.40;
      const sprite = FDSky.makeCloudSprite(c.seed, 320, 140, Math.PI*0.78);
      ctx.globalAlpha = 0.45 + c.altitude*0.45;
      ctx.drawImage(sprite, cx-cw/2, cy-ch/2, cw, ch);
      ctx.globalAlpha = 1;
    });
  }

  function drawForegroundClouds(time){
    fgClouds.forEach(c=>{
      c.x = ((c.x - c.speed * 0.016) % 1.4 + 1.4) % 1.4;
      const cx = (c.x - 0.2) * W;
      const cy = c.y * H;
      const cw = W * 0.30 * c.scale;
      const ch = cw * 0.32;
      const sprite = FDSky.makeCloudSprite(c.seed, 480, 180, Math.PI*0.78);
      ctx.globalAlpha = 0.7;
      ctx.drawImage(sprite, cx-cw/2, cy-ch/2, cw, ch);
      ctx.globalAlpha = 1;
    });
  }

  // === film grain ===
  const grainCanvas = document.createElement('canvas');
  grainCanvas.width = 200; grainCanvas.height = 200;
  const gctx = grainCanvas.getContext('2d');
  function regenGrain(){
    const img = gctx.createImageData(200, 200);
    for(let i=0;i<img.data.length;i+=4){
      const v = 128 + (Math.random()-0.5)*120;
      img.data[i]=img.data[i+1]=img.data[i+2]=v;
      img.data[i+3]=18;
    }
    gctx.putImageData(img,0,0);
  }
  let grainTick = 0;
  function addGrain(alpha){
    if(grainTick++ % 3 === 0) regenGrain();
    ctx.save();
    ctx.globalCompositeOperation = 'overlay';
    ctx.globalAlpha = alpha;
    const pat = ctx.createPattern(grainCanvas, 'repeat');
    ctx.fillStyle = pat;
    ctx.fillRect(0,0,W,H);
    ctx.restore();
  }

  function animate(ts){
    ts = ts || performance.now();
    const dt = lastTs ? (ts-lastTs)/1000 : 0.016;
    lastTs = ts;
    if(!paused){
      t += Math.min(dt, 0.05);
      try { localStorage.setItem('jetAnim_t', t.toString()); } catch(e){}
    }
    try { draw(); } catch(e){ console.error('draw err', e); }
    requestAnimationFrame(animate);
  }
  // kick off — also use a setInterval fallback for backgrounded iframes
  requestAnimationFrame(animate);
  setInterval(()=>{ if(document.hidden || performance.now()-lastTs > 200) animate(performance.now()); }, 33);

  pp.addEventListener('click', ()=>{
    paused = !paused;
    pp.textContent = paused ? '▶' : '⏸';
  });
  document.addEventListener('keydown', e=>{
    if(e.code==='Space'){ e.preventDefault(); pp.click(); }
    if(e.code==='ArrowLeft') t = Math.max(0, t-1);
    if(e.code==='ArrowRight') t = t+1;
  });
})();
