// Realistic private jet — Gulfstream-style profile
window.FDJet = (function(){
  // Draws a 3/4 perspective view of a private jet
  // sc: scale factor (1 = ~700px wide)
  // bankAngle: roll in radians
  function drawJet(ctx, cx, cy, sc, alpha, t, bankAngle=0){
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(bankAngle);
    ctx.scale(sc, sc);
    ctx.globalAlpha = alpha;

    // === SHADOW ===
    const sg = ctx.createRadialGradient(0, 95, 0, 0, 95, 280);
    sg.addColorStop(0,'rgba(0,20,40,0.32)');
    sg.addColorStop(0.5,'rgba(0,20,40,0.12)');
    sg.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle = sg;
    ctx.beginPath();
    ctx.ellipse(20, 100, 280, 38, 0, 0, Math.PI*2);
    ctx.fill();

    // === CONTRAILS (twin from engines) ===
    for(let k=0;k<2;k++){
      const ey = 22 + k*4;
      for(let i=0;i<8;i++){
        const dx = 220 + i*55;
        const fade = (1 - i/8) * (0.32 - k*0.05);
        const tw = 6 + i*1.8;
        const wob = Math.sin(t*1.4 + i*0.6 + k*1.7)*1.2;
        const g = ctx.createLinearGradient(dx, ey+wob-tw, dx, ey+wob+tw);
        g.addColorStop(0, 'rgba(255,255,255,0)');
        g.addColorStop(0.5, `rgba(255,255,255,${fade})`);
        g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(dx, ey+wob, 30 + i*4, tw, 0, 0, Math.PI*2);
        ctx.fill();
      }
    }

    // === HORIZONTAL STABILIZER (back layer, behind fuselage) ===
    const hsg = ctx.createLinearGradient(280,-82, 420,-72);
    hsg.addColorStop(0,'#d4d8df'); hsg.addColorStop(0.6,'#bcc0c6'); hsg.addColorStop(1,'#9ea2a8');
    ctx.fillStyle = hsg;
    ctx.beginPath();
    ctx.moveTo(288,-78);
    ctx.bezierCurveTo(300,-90, 345,-95, 415,-87);
    ctx.bezierCurveTo(420,-86, 420,-78, 412,-76);
    ctx.bezierCurveTo(370,-72, 320,-72, 296,-72);
    ctx.closePath(); ctx.fill();
    // shadow under stab
    ctx.fillStyle = 'rgba(0,0,0,0.18)';
    ctx.beginPath();
    ctx.moveTo(296,-72); ctx.lineTo(412,-76); ctx.lineTo(412,-73); ctx.lineTo(296,-69); ctx.closePath(); ctx.fill();

    // === VERTICAL FIN ===
    const vg = ctx.createLinearGradient(290,-15, 345,-78);
    vg.addColorStop(0,'#e0e3e8');
    vg.addColorStop(0.45,'#c8ccd2');
    vg.addColorStop(1,'#a8acb2');
    ctx.fillStyle = vg;
    ctx.beginPath();
    ctx.moveTo(298,-22);
    ctx.bezierCurveTo(300,-30, 305,-50, 318,-80);
    ctx.bezierCurveTo(322,-87, 335,-86, 340,-79);
    ctx.lineTo(355,-20);
    ctx.bezierCurveTo(345,-18, 320,-18, 298,-22);
    ctx.closePath(); ctx.fill();
    // fin shading
    const fsh = ctx.createLinearGradient(320,-80, 320,-22);
    fsh.addColorStop(0,'rgba(0,0,0,0)');
    fsh.addColorStop(1,'rgba(0,0,0,0.18)');
    ctx.fillStyle = fsh;
    ctx.beginPath();
    ctx.moveTo(298,-22); ctx.lineTo(355,-20); ctx.lineTo(345,-18); ctx.bezierCurveTo(330,-19, 305,-21, 298,-22); ctx.closePath(); ctx.fill();
    // navy stripe + logo
    ctx.fillStyle = '#13284a';
    ctx.beginPath();
    ctx.moveTo(311,-70); ctx.bezierCurveTo(315,-74, 332,-74, 336,-70);
    ctx.lineTo(340,-50); ctx.bezierCurveTo(330,-52, 318,-52, 308,-50);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#e8c97a';
    ctx.font = 'bold 9px ui-monospace,monospace';
    ctx.textAlign='center';
    ctx.fillText('FD', 324, -58);

    // === FUSELAGE — long elegant tube ===
    // top half (sunlit)
    const fTop = ctx.createLinearGradient(0,-46, 0, 12);
    fTop.addColorStop(0.0, '#fbfbfc');
    fTop.addColorStop(0.18,'#f0f1f4');
    fTop.addColorStop(0.45,'#dadde2');
    fTop.addColorStop(0.75,'#b8bcc2');
    fTop.addColorStop(1.0, '#92959c');
    ctx.fillStyle = fTop;
    ctx.beginPath();
    // nose curve
    ctx.moveTo(-318, 6);
    ctx.bezierCurveTo(-312, -28, -278, -44, -228, -45);
    // top spine to tail
    ctx.bezierCurveTo(-150, -47, 0, -42, 140, -36);
    ctx.bezierCurveTo(230, -32, 290, -28, 320, -24);
    // tail tip
    ctx.lineTo(356, -18);
    ctx.bezierCurveTo(364, -15, 364, -8, 356, -6);
    // back along belly
    ctx.lineTo(320, 0);
    ctx.bezierCurveTo(290, 4, 230, 8, 140, 12);
    ctx.bezierCurveTo(0, 18, -150, 16, -228, 12);
    ctx.bezierCurveTo(-280, 11, -310, 14, -318, 14);
    ctx.bezierCurveTo(-324, 12, -324, 8, -318, 6);
    ctx.closePath();
    ctx.fill();

    // belly (in shadow)
    const fBot = ctx.createLinearGradient(0,12, 0, 44);
    fBot.addColorStop(0, 'rgba(0,0,0,0)');
    fBot.addColorStop(0.4, 'rgba(20,30,50,0.35)');
    fBot.addColorStop(1, 'rgba(8,14,28,0.55)');
    ctx.fillStyle = fBot;
    ctx.beginPath();
    ctx.moveTo(-318, 8);
    ctx.bezierCurveTo(-290, 32, -180, 42, 0, 38);
    ctx.bezierCurveTo(180, 34, 290, 24, 356, -2);
    ctx.lineTo(356, -6);
    ctx.bezierCurveTo(290, 24, 180, 38, 0, 42);
    ctx.bezierCurveTo(-180, 46, -290, 36, -320, 14);
    ctx.closePath(); ctx.fill();

    // navy cheatline (signature stripe along windows)
    ctx.fillStyle = '#13284a';
    ctx.beginPath();
    ctx.moveTo(-260, -8);
    ctx.bezierCurveTo(-120, -12, 130, -16, 305, -14);
    ctx.lineTo(305, -10);
    ctx.bezierCurveTo(130, -12, -120, -8, -260, -4);
    ctx.closePath(); ctx.fill();
    // gold pinstripe above cheatline
    ctx.strokeStyle = '#e8c97a';
    ctx.lineWidth = 0.6;
    ctx.beginPath();
    ctx.moveTo(-260, -13);
    ctx.bezierCurveTo(-120, -17, 130, -21, 305, -19);
    ctx.stroke();

    // bright dorsal reflection
    ctx.strokeStyle = 'rgba(255,255,255,0.55)';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(-285, -35);
    ctx.bezierCurveTo(-150, -45, 50, -40, 320, -25);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-300, -22);
    ctx.bezierCurveTo(-180, -32, 30, -28, 310, -16);
    ctx.stroke();

    // nose anti-glare panel (matte black)
    ctx.fillStyle = 'rgba(15,18,28,0.92)';
    ctx.beginPath();
    ctx.moveTo(-318, -2);
    ctx.bezierCurveTo(-300, -10, -278, -14, -260, -14);
    ctx.lineTo(-258, -8);
    ctx.bezierCurveTo(-280, -8, -302, -4, -316, 2);
    ctx.closePath(); ctx.fill();

    // === WING (large, swept) — drawn after fuselage so it sits in front ===
    // wing top
    const wT = ctx.createLinearGradient(0,-22, 0, 12);
    wT.addColorStop(0, '#e2e5ea');
    wT.addColorStop(0.5,'#c2c6cc');
    wT.addColorStop(1, '#8e9298');
    ctx.fillStyle = wT;
    ctx.beginPath();
    ctx.moveTo(-90, -8);
    // leading edge (forward sweep is shorter at root, longer at tip)
    ctx.bezierCurveTo(-40, -10, 10, -8, 60, -2);
    ctx.bezierCurveTo(140, 6, 240, 22, 340, 38);
    // tip curve
    ctx.bezierCurveTo(350, 42, 350, 48, 338, 50);
    // trailing edge back to root
    ctx.bezierCurveTo(230, 50, 130, 38, 50, 26);
    ctx.bezierCurveTo(-10, 18, -55, 14, -95, 12);
    ctx.closePath(); ctx.fill();

    // wing underside shadow
    const wB = ctx.createLinearGradient(0,8, 0, 50);
    wB.addColorStop(0, 'rgba(0,0,0,0)');
    wB.addColorStop(1, 'rgba(0,0,0,0.32)');
    ctx.fillStyle = wB;
    ctx.beginPath();
    ctx.moveTo(-90, 8);
    ctx.bezierCurveTo(-10, 18, 50, 26, 130, 38);
    ctx.bezierCurveTo(230, 50, 330, 50, 338, 50);
    ctx.bezierCurveTo(330, 52, 230, 52, 130, 42);
    ctx.bezierCurveTo(50, 30, -10, 22, -90, 12);
    ctx.closePath(); ctx.fill();

    // wing leading-edge highlight
    ctx.strokeStyle = 'rgba(255,255,255,0.4)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(-85, -7);
    ctx.bezierCurveTo(60, -3, 200, 16, 340, 38);
    ctx.stroke();

    // winglet (upturned tip)
    const wlg = ctx.createLinearGradient(335, 50, 365, 18);
    wlg.addColorStop(0, '#a8acb2');
    wlg.addColorStop(0.5,'#c8ccd2');
    wlg.addColorStop(1, '#e0e3e8');
    ctx.fillStyle = wlg;
    ctx.beginPath();
    ctx.moveTo(338, 48);
    ctx.bezierCurveTo(348, 38, 358, 22, 364, 12);
    ctx.bezierCurveTo(370, 14, 372, 20, 368, 24);
    ctx.bezierCurveTo(360, 36, 352, 46, 346, 52);
    ctx.closePath(); ctx.fill();
    // winglet gold accent
    ctx.fillStyle = '#13284a';
    ctx.beginPath();
    ctx.moveTo(360, 16); ctx.lineTo(366, 14); ctx.lineTo(355, 36); ctx.lineTo(351, 36); ctx.closePath(); ctx.fill();

    // === ENGINES (rear-mounted, signature private-jet placement) ===
    [{x:175, y:-14, scale:1.0},{x:210, y:-2, scale:0.85}].forEach((e, idx)=>{
      ctx.save();
      ctx.translate(e.x, e.y);
      ctx.scale(e.scale, e.scale);
      // pylon
      ctx.fillStyle = '#9ea2a8';
      ctx.beginPath();
      ctx.moveTo(-22, -8); ctx.lineTo(8, -8);
      ctx.lineTo(5, 6); ctx.lineTo(-22, 6); ctx.closePath(); ctx.fill();
      // nacelle body
      const ng = ctx.createLinearGradient(0,-18, 0, 18);
      ng.addColorStop(0, '#f0f2f5');
      ng.addColorStop(0.4,'#cdd0d5');
      ng.addColorStop(1, '#7a7e84');
      ctx.fillStyle = ng;
      ctx.beginPath();
      ctx.ellipse(0, 5, 52, 18, 0, 0, Math.PI*2);
      ctx.fill();
      // intake (front)
      ctx.save();
      ctx.translate(-50, 5);
      const intk = ctx.createRadialGradient(0,0, 2, 0,0, 16);
      intk.addColorStop(0, 'rgba(8,10,18,1)');
      intk.addColorStop(0.55, 'rgba(45,55,75,0.95)');
      intk.addColorStop(1, 'rgba(80,90,110,0.6)');
      ctx.fillStyle = intk;
      ctx.beginPath(); ctx.ellipse(0,0, 8, 14, 0, 0, Math.PI*2); ctx.fill();
      // fan blades (subtle)
      ctx.strokeStyle = 'rgba(120,130,150,0.5)';
      ctx.lineWidth = 0.8;
      for(let b=0;b<8;b++){
        const a = b * Math.PI/4 + t*4;
        ctx.beginPath();
        ctx.moveTo(0,0);
        ctx.lineTo(Math.cos(a)*7, Math.sin(a)*13);
        ctx.stroke();
      }
      // intake rim
      ctx.strokeStyle = 'rgba(160,170,185,0.85)';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.ellipse(0,0, 8, 14, 0, 0, Math.PI*2); ctx.stroke();
      ctx.restore();
      // exhaust
      const exh = ctx.createRadialGradient(50, 5, 2, 50, 5, 18);
      exh.addColorStop(0, 'rgba(210,180,120,0.85)');
      exh.addColorStop(0.4, 'rgba(160,120,60,0.4)');
      exh.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = exh;
      ctx.beginPath(); ctx.ellipse(50, 5, 10, 16, 0, 0, Math.PI*2); ctx.fill();
      // nacelle highlight
      ctx.strokeStyle = 'rgba(255,255,255,0.55)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-48, -10); ctx.bezierCurveTo(0, -16, 30, -14, 48, -8);
      ctx.stroke();
      // gold engine stripe
      ctx.strokeStyle = 'rgba(232,201,122,0.7)';
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.moveTo(-45, 0); ctx.bezierCurveTo(0, 2, 25, 3, 48, 4);
      ctx.stroke();
      ctx.restore();
    });

    // === WINDOWS — passenger row + cockpit ===
    // long cabin windows
    const wPositions = [];
    for(let i=0;i<14;i++) wPositions.push(-200 + i*30);
    wPositions.forEach((wx,i)=>{
      const wy = -22 + i*0.2;
      // outer alu frame
      ctx.fillStyle = 'rgba(120,128,140,0.95)';
      ctx.beginPath();
      ctx.ellipse(wx, wy, 8, 5, 0, 0, Math.PI*2); ctx.fill();
      // window glass
      const gg = ctx.createLinearGradient(wx-6, wy-4, wx+6, wy+4);
      gg.addColorStop(0,'rgba(190,215,245,0.95)');
      gg.addColorStop(0.5,'rgba(80,120,180,0.9)');
      gg.addColorStop(1,'rgba(40,70,130,0.95)');
      ctx.fillStyle = gg;
      ctx.beginPath();
      ctx.ellipse(wx, wy, 6, 3.6, 0, 0, Math.PI*2); ctx.fill();
      // highlight (cabin lit warm)
      ctx.fillStyle = `rgba(255,225,170,${0.30 + Math.sin(i*1.3)*0.2})`;
      ctx.beginPath();
      ctx.ellipse(wx-1.5, wy-1, 2.5, 1.2, 0, 0, Math.PI*2); ctx.fill();
      // sun glint
      ctx.fillStyle = 'rgba(255,255,255,0.7)';
      ctx.beginPath();
      ctx.ellipse(wx+2, wy-1.6, 1.3, 0.6, 0, 0, Math.PI*2); ctx.fill();
    });

    // cockpit windscreen (multi-pane)
    const cg = ctx.createLinearGradient(-300, -36, -220, -8);
    cg.addColorStop(0,'rgba(45,75,130,0.95)');
    cg.addColorStop(0.5,'rgba(80,120,180,0.85)');
    cg.addColorStop(1,'rgba(160,200,240,0.75)');
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.moveTo(-302, -2);
    ctx.bezierCurveTo(-296, -22, -278, -36, -250, -38);
    ctx.bezierCurveTo(-225, -39, -205, -32, -195, -22);
    ctx.lineTo(-195, -10);
    ctx.bezierCurveTo(-220, -16, -270, -14, -302, -2);
    ctx.closePath(); ctx.fill();
    // cockpit frame divisions
    ctx.strokeStyle = 'rgba(40,46,58,0.85)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-260, -37); ctx.lineTo(-260, -12); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-228, -38); ctx.lineTo(-228, -16); ctx.stroke();
    // cockpit reflection (sun streak)
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.beginPath();
    ctx.moveTo(-294, -6);
    ctx.bezierCurveTo(-286, -22, -270, -32, -250, -34);
    ctx.lineTo(-254, -28);
    ctx.bezierCurveTo(-272, -24, -284, -16, -290, -2);
    ctx.closePath(); ctx.fill();

    // === NAV LIGHTS ===
    const blink = 0.5 + 0.5*Math.abs(Math.sin(t*3));
    // red port wing (left)
    ctx.fillStyle = `rgba(255,40,60,${0.7+blink*0.3})`;
    ctx.shadowColor = '#ff2040';
    ctx.shadowBlur = blink*22;
    ctx.beginPath(); ctx.arc(-90, 12, 3.5, 0, Math.PI*2); ctx.fill();
    ctx.shadowBlur = 0;
    // green starboard tip
    ctx.fillStyle = 'rgba(50,255,90,0.9)';
    ctx.shadowColor = '#30ff50';
    ctx.shadowBlur = 14;
    ctx.beginPath(); ctx.arc(366, 14, 2.8, 0, Math.PI*2); ctx.fill();
    ctx.shadowBlur = 0;
    // tail strobe
    const strobe = Math.pow(Math.abs(Math.sin(t*3.2)), 8);
    ctx.fillStyle = `rgba(255,255,230,${strobe})`;
    ctx.shadowColor = '#fffacc';
    ctx.shadowBlur = strobe*25;
    ctx.beginPath(); ctx.arc(354, -10, 2.5, 0, Math.PI*2); ctx.fill();
    ctx.shadowBlur = 0;

    // registration tag
    ctx.fillStyle = 'rgba(40,46,60,0.7)';
    ctx.font = 'bold 8px ui-monospace,monospace';
    ctx.textAlign='center';
    ctx.fillText('F-FDLX', 260, -2);

    ctx.globalAlpha = 1;
    ctx.restore();
  }

  return {drawJet};
})();
