// Earth curvature seen from high altitude
window.FDEarth = (function(){
  const {rnd, fbm, clamp} = window.FD;

  let cache = null;
  function makeEarthTexture(W, H){
    if(cache && cache.W === W && cache.H === H) return cache.canvas;
    const c = document.createElement('canvas');
    c.width = W; c.height = Math.max(120, Math.floor(H*0.3));
    const x = c.getContext('2d');
    const tH = c.height;

    // base ocean
    const ocean = x.createLinearGradient(0, 0, 0, tH);
    ocean.addColorStop(0, '#3b6890');
    ocean.addColorStop(0.5, '#2a5274');
    ocean.addColorStop(1, '#1f3a55');
    x.fillStyle = ocean; x.fillRect(0,0,W,tH);

    // land masses using fbm
    const img = x.getImageData(0,0,W,tH);
    const d = img.data;
    for(let py=0;py<tH;py++){
      for(let px=0;px<W;px++){
        const i = (py*W+px)*4;
        // domain-warped fbm to make land outlines feel organic
        const nx = px/W * 6;
        const ny = py/tH * 2.5;
        const warp = fbm(nx*0.7, ny*0.7, 3);
        const n = fbm(nx + warp*1.5, ny + warp*1.2, 5);
        // perspective: closer rows (bottom) more compressed
        const v = n; 
        if(v > 0.55){
          // land
          const alt = (v-0.55)/0.45;
          // greens to browns
          const veg = fbm(nx*3.1, ny*3.1, 3);
          let r,g,b;
          if(alt < 0.15){
            // coastal — sandy/marsh
            r=180; g=170; b=130;
          } else if(veg > 0.55){
            // forest
            r = 60 + alt*40;
            g = 95 + alt*55;
            b = 50 + alt*30;
          } else {
            // grassland / arid
            r = 130 + alt*60;
            g = 130 + alt*45;
            b = 80 + alt*25;
          }
          // high altitude mountain top
          if(alt > 0.82){
            r=lerp(r, 235, (alt-0.82)/0.18);
            g=lerp(g, 240, (alt-0.82)/0.18);
            b=lerp(b, 248, (alt-0.82)/0.18);
          }
          d[i]=r; d[i+1]=g; d[i+2]=b; d[i+3]=255;
        } else if(v > 0.50){
          // shallow water — turquoise
          const t = (v-0.50)/0.05;
          d[i]   = lerp(50, 90, t);
          d[i+1] = lerp(95, 150, t);
          d[i+2] = lerp(130, 170, t);
          d[i+3] = 255;
        }
        // else ocean (already filled)
      }
    }
    x.putImageData(img,0,0);

    // sparse cloud layer over Earth (looks like satellite view)
    x.globalCompositeOperation = 'screen';
    for(let i=0;i<28;i++){
      const cx = rnd(i*11.3)*W;
      const cy = rnd(i*7.7)*tH*0.85;
      const r = 30 + rnd(i*3.1)*70;
      const g = x.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, 'rgba(255,255,255,0.55)');
      g.addColorStop(0.6, 'rgba(255,255,255,0.18)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      x.fillStyle = g;
      x.beginPath(); x.arc(cx, cy, r, 0, Math.PI*2); x.fill();
    }
    x.globalCompositeOperation = 'source-over';

    cache = {W, H, canvas:c};
    return c;
  }
  const lerp=(a,b,t)=>a+(b-a)*t;

  function drawEarth(ctx, W, H, tFactor){
    const tex = makeEarthTexture(W, H);
    const hz = H*0.82;
    const earthH = H - hz + 8;
    // Curvature: draw texture on a slightly curved path using path clip
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, hz+H*0.045);
    ctx.bezierCurveTo(W*0.28, hz-H*0.012, W*0.72, hz-H*0.012, W, hz+H*0.045);
    ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();
    ctx.clip();

    // texture with horizontal scroll (slow)
    const scroll = (tFactor*40) % W;
    ctx.drawImage(tex, -scroll, hz - 14, W, earthH+20);
    ctx.drawImage(tex, W-scroll, hz - 14, W, earthH+20);

    // atmospheric haze near horizon (de-saturates ground)
    const haze = ctx.createLinearGradient(0, hz, 0, hz + earthH*0.55);
    haze.addColorStop(0, 'rgba(180,210,240,0.85)');
    haze.addColorStop(0.4, 'rgba(155,195,225,0.35)');
    haze.addColorStop(1, 'rgba(120,170,205,0)');
    ctx.fillStyle = haze;
    ctx.fillRect(0, hz-4, W, earthH*0.7);

    ctx.restore();

    // Bright horizon glow line
    const glow = ctx.createLinearGradient(0, hz-H*0.04, 0, hz+H*0.04);
    glow.addColorStop(0,'rgba(220,235,255,0)');
    glow.addColorStop(0.5,'rgba(220,235,255,0.55)');
    glow.addColorStop(1,'rgba(220,235,255,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(0, hz-H*0.04, W, H*0.08);

    // soft horizon line
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(0, hz+H*0.045);
    ctx.bezierCurveTo(W*0.28, hz-H*0.012, W*0.72, hz-H*0.012, W, hz+H*0.045);
    ctx.stroke();
  }

  return {drawEarth};
})();
