// Shared utilities + state
window.FD = (function(){
  const ease = x => x<.5 ? 2*x*x : 1-Math.pow(-2*x+2,2)/2;
  const easeOut = x => 1 - Math.pow(1-x, 3);
  const easeIn = x => x*x*x;
  const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));
  const lerp = (a,b,t)=>a+(b-a)*t;
  const smoothstep = (a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};
  // deterministic pseudo-rand
  const rnd = (i)=> {
    const s = Math.sin(i*9301.7 + 49297.13) * 233280.55;
    return s - Math.floor(s);
  };
  // procedural noise (2d, smooth)
  const noise2 = (x,y)=>{
    const xi=Math.floor(x), yi=Math.floor(y);
    const xf=x-xi, yf=y-yi;
    const u=xf*xf*(3-2*xf), v=yf*yf*(3-2*yf);
    const n=(a,b)=>rnd(a*73.1+b*311.7);
    const a=n(xi,yi),b=n(xi+1,yi),c=n(xi,yi+1),d=n(xi+1,yi+1);
    return lerp(lerp(a,b,u), lerp(c,d,u), v);
  };
  const fbm = (x,y,oct=4)=>{
    let v=0,amp=.5,fr=1;
    for(let i=0;i<oct;i++){v+=amp*noise2(x*fr,y*fr); fr*=2; amp*=.5;}
    return v;
  };
  return {ease,easeOut,easeIn,clamp,lerp,smoothstep,rnd,noise2,fbm};
})();
