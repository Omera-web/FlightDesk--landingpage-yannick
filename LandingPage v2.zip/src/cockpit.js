// Cockpit interior — REAR POV (camera between/behind the seats, looking forward)
// Only the upper backs / headrests of the two pilot seats appear at the bottom corners.
// Futuristic concept jet: carbon shell, LED accent edges, curved holo dashboard.
window.FDCockpit = (function(){
  const {clamp, lerp, smoothstep} = window.FD;

  // ───────── REALISTIC VOLUMETRIC WINDOW VIEW ─────────
  // The windscreen looks out onto a stratified sky with layered clouds,
  // strong atmospheric haze, sun blooming with subtle god-rays.
  function drawWindowView(ctx, x, y, w, h, t, alpha){
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.clip();

    // ── ATMOSPHERIC SKY (atmospheric scattering, high altitude)
    const sky = ctx.createLinearGradient(x, y, x, y+h);
    sky.addColorStop(0.00, `rgba(7,18,46,${alpha})`);
    sky.addColorStop(0.18, `rgba(15,40,82,${alpha})`);
    sky.addColorStop(0.40, `rgba(38,82,138,${alpha})`);
    sky.addColorStop(0.60, `rgba(96,140,182,${alpha})`);
    sky.addColorStop(0.75, `rgba(180,205,225,${alpha})`);
    sky.addColorStop(0.88, `rgba(220,228,235,${alpha})`);
    sky.addColorStop(1.00, `rgba(232,235,238,${alpha})`);
    ctx.fillStyle = sky;
    ctx.fillRect(x, y, w, h);

    // ── SUN (low-right of the windscreen so it back-lights the clouds)
    const sunX = x + w*0.72;
    const sunY = y + h*0.30;
    // wide atmospheric glow
    const amb = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, h*1.25);
    amb.addColorStop(0,    `rgba(255,240,205,${alpha*0.30})`);
    amb.addColorStop(0.20, `rgba(255,225,165,${alpha*0.15})`);
    amb.addColorStop(0.50, `rgba(255,200,135,${alpha*0.04})`);
    amb.addColorStop(1,    'rgba(0,0,0,0)');
    ctx.fillStyle = amb;
    ctx.fillRect(x, y, w, h);
    // halo
    const halo = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, h*0.30);
    halo.addColorStop(0,    `rgba(255,250,225,${alpha*0.95})`);
    halo.addColorStop(0.18, `rgba(255,240,195,${alpha*0.55})`);
    halo.addColorStop(0.45, `rgba(255,225,160,${alpha*0.16})`);
    halo.addColorStop(1,    'rgba(0,0,0,0)');
    ctx.fillStyle = halo;
    ctx.fillRect(x, y, w, h);
    // disc
    const core = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, h*0.07);
    core.addColorStop(0,   `rgba(255,255,250,${alpha})`);
    core.addColorStop(0.5, `rgba(255,245,210,${alpha*0.85})`);
    core.addColorStop(1,   'rgba(255,240,180,0)');
    ctx.fillStyle = core;
    ctx.beginPath(); ctx.arc(sunX, sunY, h*0.07, 0, Math.PI*2); ctx.fill();

    // ── HIGH CIRRUS STREAKS (long, wispy, parallel)
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    const drift = t*3;
    for(let i=0;i<7;i++){
      const cy = y + h*(0.14 + i*0.035);
      const cw = w*1.4;
      const cx = x - w*0.2 + ((i*w*0.18 + drift) % cw);
      const ch = 2 + (i%3);
      const grd = ctx.createLinearGradient(cx, cy, cx+cw*0.7, cy);
      grd.addColorStop(0,   'rgba(255,255,255,0)');
      grd.addColorStop(0.4, `rgba(255,250,240,${alpha*0.10})`);
      grd.addColorStop(0.7, `rgba(255,250,240,${alpha*0.06})`);
      grd.addColorStop(1,   'rgba(255,255,255,0)');
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.ellipse(cx+cw*0.35, cy, cw*0.45, ch, 0, 0, Math.PI*2);
      ctx.fill();
    }
    ctx.restore();

    // ── STRATIFIED CLOUD LAYER (sea of clouds below us)
    // Two sub-layers: distant haze band + foreground volumetric cumulus tops
    const cloudTopY = y + h*0.55;

    // Thick atmospheric haze band at horizon
    const haze = ctx.createLinearGradient(0, cloudTopY-h*0.12, 0, y+h);
    haze.addColorStop(0,    'rgba(212,222,232,0)');
    haze.addColorStop(0.18, `rgba(212,222,232,${alpha*0.35})`);
    haze.addColorStop(0.45, `rgba(225,232,240,${alpha*0.75})`);
    haze.addColorStop(0.80, `rgba(232,238,244,${alpha*0.92})`);
    haze.addColorStop(1,    `rgba(240,244,248,${alpha*0.98})`);
    ctx.fillStyle = haze;
    ctx.fillRect(x, cloudTopY-h*0.12, w, h);

    // Volumetric cloud tops — multiple irregular layers, lit from upper-right
    // Background distant layer — wispy, low contrast
    for(let i=0;i<18;i++){
      const seed = i*7.3 + 11;
      const driftX = ((t*0.004 + i*0.07) * w) % (w*1.3);
      const px = x - w*0.15 + driftX;
      const py = cloudTopY + h*(0.04 + (Math.sin(seed*3.1)*0.5+0.5)*0.18) + Math.sin(seed*7.3 + t*0.04)*h*0.008;
      const pr = h * (0.06 + (Math.sin(seed*5.7)*0.5+0.5)*0.06);
      // wispy body, no hard edges
      const bg = ctx.createRadialGradient(px, py, 0, px, py, pr*1.6);
      bg.addColorStop(0,    `rgba(245,248,253,${alpha*0.55})`);
      bg.addColorStop(0.45, `rgba(225,234,245,${alpha*0.30})`);
      bg.addColorStop(0.80, `rgba(215,225,238,${alpha*0.08})`);
      bg.addColorStop(1,    'rgba(215,225,238,0)');
      ctx.fillStyle = bg;
      ctx.beginPath(); ctx.ellipse(px, py, pr*1.6, pr*0.45, 0, 0, Math.PI*2); ctx.fill();
      // sun-side warm tint
      const hl = ctx.createRadialGradient(px+pr*0.4, py-pr*0.15, 0, px+pr*0.4, py-pr*0.15, pr*1.0);
      hl.addColorStop(0, `rgba(255,245,220,${alpha*0.35})`);
      hl.addColorStop(1, 'rgba(255,240,210,0)');
      ctx.fillStyle = hl;
      ctx.beginPath(); ctx.ellipse(px+pr*0.3, py-pr*0.10, pr*1.0, pr*0.35, 0, 0, Math.PI*2); ctx.fill();
    }

    // Closer foreground cumulus tops — wide, soft, atmospheric (not puffy cartoon)
    // Lower opacity, larger spread, no sharp edges. Layered like real cloud strata.
    for(let i=0;i<7;i++){
      const seed = i*11.7 + 3;
      const driftX = ((t*0.010 + i*0.16) * w*1.5) % (w*1.7);
      const px = x - w*0.30 + driftX;
      const py = y + h*0.88 + Math.sin(seed*3.1)*h*0.025;
      const pr = h * (0.26 + (Math.sin(seed*5.7)*0.5+0.5)*0.14);
      // wide flat shadow underneath
      const sg = ctx.createRadialGradient(px, py+pr*0.25, 0, px, py+pr*0.25, pr*1.8);
      sg.addColorStop(0,   `rgba(130,150,175,${alpha*0.30})`);
      sg.addColorStop(0.6, `rgba(150,165,185,${alpha*0.10})`);
      sg.addColorStop(1, 'rgba(150,165,185,0)');
      ctx.fillStyle = sg;
      ctx.beginPath(); ctx.ellipse(px, py+pr*0.3, pr*1.9, pr*0.42, 0, 0, Math.PI*2); ctx.fill();
      // wide soft body — single large diffuse blob, low contrast
      const bg = ctx.createRadialGradient(px, py-pr*0.05, 0, px, py, pr*1.5);
      bg.addColorStop(0,    `rgba(248,250,254,${alpha*0.70})`);
      bg.addColorStop(0.35, `rgba(232,240,250,${alpha*0.50})`);
      bg.addColorStop(0.70, `rgba(218,228,240,${alpha*0.18})`);
      bg.addColorStop(1,    'rgba(218,228,240,0)');
      ctx.fillStyle = bg;
      ctx.beginPath(); ctx.ellipse(px, py, pr*1.6, pr*0.50, 0, 0, Math.PI*2); ctx.fill();
      // sun-side warm tint, very soft
      const hl = ctx.createRadialGradient(px+pr*0.5, py-pr*0.15, 0, px+pr*0.5, py-pr*0.15, pr*1.2);
      hl.addColorStop(0,   `rgba(255,243,215,${alpha*0.35})`);
      hl.addColorStop(0.5, `rgba(255,238,205,${alpha*0.12})`);
      hl.addColorStop(1,   'rgba(255,235,200,0)');
      ctx.fillStyle = hl;
      ctx.beginPath(); ctx.ellipse(px+pr*0.4, py-pr*0.10, pr*1.3, pr*0.40, 0, 0, Math.PI*2); ctx.fill();
    }

    // ── SUBTLE GOD-RAYS from sun
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.translate(sunX, sunY);
    for(let i=0;i<5;i++){
      const ang = -Math.PI*0.45 + i*0.10;
      const len = h*1.6;
      const rg = ctx.createLinearGradient(0,0, Math.cos(ang)*len, Math.sin(ang)*len);
      rg.addColorStop(0,   `rgba(255,243,210,${alpha*0.08})`);
      rg.addColorStop(0.6, `rgba(255,235,190,${alpha*0.025})`);
      rg.addColorStop(1,   'rgba(255,235,190,0)');
      ctx.fillStyle = rg;
      ctx.beginPath();
      ctx.moveTo(0,0);
      ctx.lineTo(Math.cos(ang-0.04)*len, Math.sin(ang-0.04)*len);
      ctx.lineTo(Math.cos(ang+0.04)*len, Math.sin(ang+0.04)*len);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();

    // ── FINAL ATMOSPHERIC TINT (lifts blacks, gives film-look)
    const film = ctx.createLinearGradient(x, y, x, y+h);
    film.addColorStop(0, `rgba(40,60,100,${alpha*0.10})`);
    film.addColorStop(1, `rgba(255,235,205,${alpha*0.05})`);
    ctx.fillStyle = film;
    ctx.fillRect(x, y, w, h);

    ctx.restore();
  }

  // ───────── FUTURISTIC SEAT BACK — viewed from BEHIND
  // We see only the upper portion: shoulders + headrest. The seat curves
  // away from us. Bottom of frame = top of seat back.
  // side: -1 = left seat, +1 = right seat
  function drawSeatBack(ctx, cx, baseY, w, h, alpha, side, accentColor, badgeText){
    ctx.save();
    ctx.globalAlpha = alpha;

    // Geometry overview (looking from behind):
    //   Headrest:  rounded rectangle, slightly tilted forward, top is highest
    //   Shoulders: wider area below headrest, taper outward then curve down
    //   The seat "extends down" off-screen (below baseY+h)
    //
    // We draw layers back-to-front:
    //   1) outer carbon shell (dark, anguleux)
    //   2) leather inner panel facing pilot (only thin strip visible)
    //   3) LED accent strip along center seam (lit)
    //   4) headrest pillow on top
    //   5) embossed logo/badge centerline

    const tilt = side * 0.06; // slight inward tilt
    ctx.translate(cx, baseY);
    ctx.rotate(tilt);

    // ── 1) OUTER CARBON SHELL
    // Tall, narrow, anguleux silhouette. Sharp chamfers, no soft curves.
    // From rear we see: rectangular headrest on top, slim shoulders, body tapering off-screen.
    const shellG = ctx.createLinearGradient(-w*0.45, 0, w*0.45, 0);
    shellG.addColorStop(0,    '#04060a');
    shellG.addColorStop(0.20, '#0a0d14');
    shellG.addColorStop(0.50, '#13171f');
    shellG.addColorStop(0.80, '#0a0d14');
    shellG.addColorStop(1,    '#04060a');
    ctx.fillStyle = shellG;
    ctx.beginPath();
    // bottom-left (off-screen)
    ctx.moveTo(-w*0.50, h*1.10);
    // up the left flank — straight
    ctx.lineTo(-w*0.42, h*0.30);
    // chamfer in to shoulder
    ctx.lineTo(-w*0.32, h*0.05);
    // up to headrest base (slim taper)
    ctx.lineTo(-w*0.22, -h*0.05);
    // chamfered top-left corner
    ctx.lineTo(-w*0.20, -h*0.22);
    ctx.lineTo(-w*0.15, -h*0.28);
    // headrest top — nearly flat (slightly arched)
    ctx.bezierCurveTo(-w*0.05, -h*0.30, w*0.05, -h*0.30, w*0.15, -h*0.28);
    // chamfered top-right
    ctx.lineTo(w*0.20, -h*0.22);
    ctx.lineTo(w*0.22, -h*0.05);
    // down to right shoulder
    ctx.lineTo(w*0.32, h*0.05);
    ctx.lineTo(w*0.42, h*0.30);
    ctx.lineTo(w*0.50, h*1.10);
    ctx.closePath();
    ctx.fill();

    // carbon-fiber weave pattern (subtle hexagonal stipple)
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-w*0.42, h*0.30); ctx.lineTo(-w*0.32, h*0.05);
    ctx.lineTo(-w*0.22, -h*0.05); ctx.lineTo(-w*0.20, -h*0.22);
    ctx.lineTo(-w*0.15, -h*0.28);
    ctx.bezierCurveTo(-w*0.05, -h*0.30, w*0.05, -h*0.30, w*0.15, -h*0.28);
    ctx.lineTo(w*0.20, -h*0.22); ctx.lineTo(w*0.22, -h*0.05);
    ctx.lineTo(w*0.32, h*0.05); ctx.lineTo(w*0.42, h*0.30);
    ctx.lineTo(w*0.50, h*1.10); ctx.lineTo(-w*0.50, h*1.10);
    ctx.closePath();
    ctx.clip();
    ctx.fillStyle = 'rgba(255,255,255,0.022)';
    for(let i=-30;i<30;i++) ctx.fillRect(i*w*0.04 - w*0.5, -h*0.3, 0.7, h*1.5);
    ctx.fillStyle = 'rgba(0,0,0,0.22)';
    for(let i=-30;i<30;i++) ctx.fillRect(-w*0.6, i*h*0.022, w*1.2, 0.45);
    ctx.restore();

    // ── 2) SOFT RIM HIGHLIGHT along outer silhouette (ambient cabin light)
    ctx.strokeStyle = 'rgba(160,180,210,0.45)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(-w*0.42, h*0.30); ctx.lineTo(-w*0.32, h*0.05);
    ctx.lineTo(-w*0.22, -h*0.05); ctx.lineTo(-w*0.20, -h*0.22);
    ctx.lineTo(-w*0.15, -h*0.28);
    ctx.bezierCurveTo(-w*0.05, -h*0.30, w*0.05, -h*0.30, w*0.15, -h*0.28);
    ctx.lineTo(w*0.20, -h*0.22); ctx.lineTo(w*0.22, -h*0.05);
    ctx.lineTo(w*0.32, h*0.05); ctx.lineTo(w*0.42, h*0.30);
    ctx.stroke();

    // ── 3) INSET DARK PANEL (deep charcoal, gives the seat depth)
    const innerG = ctx.createLinearGradient(0, -h*0.20, 0, h*0.95);
    innerG.addColorStop(0,    '#16191f');
    innerG.addColorStop(0.5,  '#0a0c12');
    innerG.addColorStop(1,    '#040508');
    ctx.fillStyle = innerG;
    ctx.beginPath();
    ctx.moveTo(-w*0.36, h*0.30);
    ctx.lineTo(-w*0.28, h*0.06);
    ctx.lineTo(-w*0.18, -h*0.04);
    ctx.lineTo(-w*0.16, -h*0.20);
    ctx.lineTo(-w*0.11, -h*0.25);
    ctx.bezierCurveTo(-w*0.03, -h*0.26, w*0.03, -h*0.26, w*0.11, -h*0.25);
    ctx.lineTo(w*0.16, -h*0.20);
    ctx.lineTo(w*0.18, -h*0.04);
    ctx.lineTo(w*0.28, h*0.06);
    ctx.lineTo(w*0.36, h*0.30);
    ctx.lineTo(w*0.44, h*1.10);
    ctx.lineTo(-w*0.44, h*1.10);
    ctx.closePath();
    ctx.fill();

    // ── 4) HORIZONTAL PANEL SEAMS (sharp horizontal lines, anguleux)
    ctx.strokeStyle = 'rgba(0,0,0,0.65)';
    ctx.lineWidth = 0.7;
    for(let i=0;i<4;i++){
      const py = h*(0.10 + i*0.22);
      ctx.beginPath();
      ctx.moveTo(-w*0.32 + i*w*0.015, py);
      ctx.lineTo(w*0.32 - i*w*0.015, py);
      ctx.stroke();
    }

    // ── 5) DUAL LED ACCENT STRIPS (running down the spine of the seat)
    // The signature futuristic detail: thin glowing lines on either side of a center channel.
    const ledTop = -h*0.05;
    const ledBot = h*1.10;
    [-w*0.06, w*0.06].forEach(lx => {
      // outer halo
      const glowG = ctx.createLinearGradient(lx-w*0.04, 0, lx+w*0.04, 0);
      glowG.addColorStop(0,   `rgba(${accentColor},0)`);
      glowG.addColorStop(0.5, `rgba(${accentColor},0.65)`);
      glowG.addColorStop(1,   `rgba(${accentColor},0)`);
      ctx.fillStyle = glowG;
      ctx.fillRect(lx-w*0.04, ledTop, w*0.08, ledBot-ledTop);
      // bright core
      ctx.fillStyle = `rgba(${accentColor},1)`;
      ctx.fillRect(lx-0.9, ledTop, 1.8, ledBot-ledTop);
      // white-hot center
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.fillRect(lx-0.3, ledTop, 0.6, ledBot-ledTop);
    });
    // central channel (darker recess between the two LEDs)
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(-w*0.02, ledTop, w*0.04, ledBot-ledTop);

    // ── 6) HEADREST EMBEDDED SCREEN (futuristic: little OLED on the back of the seat)
    // Sharp rectangle with accent color glow.
    const scrX = -w*0.10, scrY = -h*0.22, scrW = w*0.20, scrH = h*0.10;
    // recessed dark plate
    ctx.fillStyle = '#02030680';
    if(ctx.roundRect){ ctx.beginPath(); ctx.roundRect(scrX-2, scrY-2, scrW+4, scrH+4, 3); ctx.fill(); }
    else ctx.fillRect(scrX-2, scrY-2, scrW+4, scrH+4);
    // OLED screen face
    const oledG = ctx.createLinearGradient(scrX, scrY, scrX, scrY+scrH);
    oledG.addColorStop(0, `rgba(${accentColor},0.18)`);
    oledG.addColorStop(1, `rgba(${accentColor},0.05)`);
    ctx.fillStyle = oledG;
    if(ctx.roundRect){ ctx.beginPath(); ctx.roundRect(scrX, scrY, scrW, scrH, 2); ctx.fill(); }
    else ctx.fillRect(scrX, scrY, scrW, scrH);
    // monogram
    ctx.fillStyle = `rgba(${accentColor},0.95)`;
    ctx.font = `600 ${Math.round(h*0.045)}px ui-monospace,monospace`;
    ctx.textAlign='center';
    ctx.textBaseline='middle';
    ctx.fillText(badgeText || 'AV·01', 0, scrY+scrH*0.5);
    ctx.textBaseline='alphabetic';
    // glow halo around screen
    const haloG = ctx.createRadialGradient(0, scrY+scrH*0.5, 0, 0, scrY+scrH*0.5, w*0.18);
    haloG.addColorStop(0, `rgba(${accentColor},0.25)`);
    haloG.addColorStop(1, `rgba(${accentColor},0)`);
    ctx.fillStyle = haloG;
    ctx.fillRect(-w*0.20, scrY-h*0.05, w*0.40, scrH+h*0.10);

    // ── 7) METALLIC SHOULDER WING (single accent strip on each shoulder)
    ctx.fillStyle = 'rgba(140,150,168,0.55)';
    ctx.beginPath();
    ctx.moveTo(-w*0.32, h*0.05); ctx.lineTo(-w*0.27, h*0.07);
    ctx.lineTo(-w*0.22, -h*0.02); ctx.lineTo(-w*0.27, -h*0.04);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(w*0.32, h*0.05); ctx.lineTo(w*0.27, h*0.07);
    ctx.lineTo(w*0.22, -h*0.02); ctx.lineTo(w*0.27, -h*0.04);
    ctx.closePath();
    ctx.fill();
    // thin LED strip on each shoulder
    ctx.fillStyle = `rgba(${accentColor},0.85)`;
    ctx.fillRect(-w*0.30, h*0.025, w*0.06, 0.8);
    ctx.fillRect(w*0.24, h*0.025, w*0.06, 0.8);

    // ── 8) UNDER-SEAT AMBIENT SPILL (soft glow on cabin floor, leaks out from LED)
    const spill = ctx.createRadialGradient(0, h*1.05, 0, 0, h*1.05, w*0.7);
    spill.addColorStop(0, `rgba(${accentColor},${alpha*0.22})`);
    spill.addColorStop(1, `rgba(${accentColor},0)`);
    ctx.fillStyle = spill;
    ctx.fillRect(-w, h*0.7, w*2, h*0.5);

    ctx.globalAlpha = 1;
    ctx.restore();
  }

  // ───────── GLASS COCKPIT DISPLAYS ─────────
  function drawPFD(ctx, sc, t, alpha){
    const {x, y, w, h} = sc;
    ctx.save();
    ctx.beginPath(); ctx.rect(x,y,w,h); ctx.clip();
    ctx.fillStyle = `rgba(2,4,10,${alpha})`;
    ctx.fillRect(x,y,w,h);
    const ax = x+w*0.55, ay = y+h*0.5, aR = Math.min(w,h)*0.36;
    const pitch = Math.sin(t*0.25)*4;
    const roll = Math.sin(t*0.17)*5;
    const ppx = pitch * (aR/24);
    ctx.save();
    ctx.translate(ax, ay);
    ctx.rotate(roll * Math.PI/180);
    const sky = ctx.createLinearGradient(0,-aR*1.5, 0, ppx);
    sky.addColorStop(0, `rgba(8,52,120,${alpha})`);
    sky.addColorStop(1, `rgba(20,82,160,${alpha})`);
    ctx.fillStyle = sky;
    ctx.fillRect(-aR*2, -aR*2, aR*4, aR*2+ppx);
    const gnd = ctx.createLinearGradient(0, ppx, 0, aR*2);
    gnd.addColorStop(0, `rgba(110,55,15,${alpha})`);
    gnd.addColorStop(1, `rgba(55,28,8,${alpha})`);
    ctx.fillStyle = gnd;
    ctx.fillRect(-aR*2, ppx, aR*4, aR*2);
    ctx.strokeStyle = `rgba(255,255,255,${alpha})`;
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(-aR*2, ppx); ctx.lineTo(aR*2, ppx); ctx.stroke();
    for(let d=-30;d<=30;d+=5){
      if(d===0) continue;
      const ly = ppx - d*(aR/24);
      const ll = (d%10===0?aR*0.35:aR*0.18);
      ctx.strokeStyle = `rgba(255,255,255,${alpha*(d%10===0?0.7:0.4)})`;
      ctx.lineWidth = d%10===0?1.3:0.9;
      ctx.beginPath(); ctx.moveTo(-ll/2, ly); ctx.lineTo(ll/2, ly); ctx.stroke();
    }
    ctx.restore();
    ctx.strokeStyle = `rgba(255,200,40,${alpha})`;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(ax-aR*0.55, ay); ctx.lineTo(ax-aR*0.18, ay);
    ctx.moveTo(ax+aR*0.18, ay); ctx.lineTo(ax+aR*0.55, ay);
    ctx.moveTo(ax-aR*0.04, ay); ctx.lineTo(ax, ay-aR*0.10); ctx.lineTo(ax+aR*0.04, ay);
    ctx.stroke();
    // speed
    const tw = w*0.13;
    ctx.fillStyle = `rgba(8,12,22,${alpha*0.92})`;
    ctx.fillRect(x+w*0.02, y+h*0.18, tw, h*0.64);
    ctx.strokeStyle = `rgba(0,200,255,${alpha*0.4})`;
    ctx.strokeRect(x+w*0.02, y+h*0.18, tw, h*0.64);
    const spd = 482 + Math.round(Math.sin(t*0.3)*3);
    ctx.fillStyle = `rgba(255,255,255,${alpha})`;
    ctx.font = `600 ${Math.round(h*0.13)}px ui-monospace,monospace`;
    ctx.textAlign='center';
    ctx.fillText(spd, x+w*0.02+tw/2, y+h*0.55);
    // alt
    const tx2 = x+w-w*0.02-tw;
    ctx.fillStyle = `rgba(8,12,22,${alpha*0.92})`;
    ctx.fillRect(tx2, y+h*0.18, tw, h*0.64);
    ctx.strokeStyle = `rgba(0,200,255,${alpha*0.4})`;
    ctx.strokeRect(tx2, y+h*0.18, tw, h*0.64);
    const alt = 41000 + Math.round(Math.sin(t*0.19)*30);
    ctx.fillStyle = `rgba(255,255,255,${alpha})`;
    ctx.font = `600 ${Math.round(h*0.10)}px ui-monospace,monospace`;
    ctx.fillText(alt, tx2+tw/2, y+h*0.55);
    ctx.fillStyle = `rgba(0,200,255,${alpha*0.9})`;
    ctx.font = `600 ${Math.round(h*0.08)}px ui-monospace,monospace`;
    ctx.fillText('HDG 284°', ax, y+h*0.95);
    ctx.restore();
  }

  function drawMFD(ctx, sc, t, alpha){
    const {x, y, w, h} = sc;
    ctx.save();
    ctx.beginPath(); ctx.rect(x,y,w,h); ctx.clip();
    ctx.fillStyle = `rgba(4,7,14,${alpha})`;
    ctx.fillRect(x,y,w,h);
    const mg = ctx.createRadialGradient(x+w/2, y+h*0.55, 0, x+w/2, y+h*0.55, h*0.6);
    mg.addColorStop(0, `rgba(18,30,55,${alpha})`);
    mg.addColorStop(1, `rgba(6,10,20,${alpha})`);
    ctx.fillStyle = mg;
    ctx.fillRect(x, y+h*0.15, w, h*0.85);
    ctx.strokeStyle = `rgba(120,180,255,${alpha*0.18})`;
    ctx.lineWidth = 0.8;
    for(let i=1;i<=4;i++){
      ctx.beginPath();
      ctx.arc(x+w/2, y+h*0.82, h*0.16*i, -Math.PI*0.75, -Math.PI*0.25);
      ctx.stroke();
    }
    ctx.strokeStyle = `rgba(180,140,255,${alpha*0.85})`;
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    ctx.moveTo(x+w/2, y+h*0.82);
    ctx.lineTo(x+w*0.62, y+h*0.45);
    ctx.lineTo(x+w*0.85, y+h*0.30);
    ctx.stroke();
    ctx.setLineDash([]);
    [
      {wx: w*0.62, wy: h*0.45, n: 'KESLA'},
      {wx: w*0.85, wy: h*0.30, n: 'BIKAR'},
      {wx: w*0.30, wy: h*0.60, n: 'ROMEO'},
    ].forEach(p=>{
      ctx.fillStyle = `rgba(180,140,255,${alpha})`;
      ctx.beginPath(); ctx.arc(x+p.wx, y+p.wy, 3, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = `rgba(220,210,255,${alpha*0.85})`;
      ctx.font = `500 ${Math.round(h*0.06)}px ui-monospace,monospace`;
      ctx.textAlign='left';
      ctx.fillText(p.n, x+p.wx+6, y+p.wy+3);
    });
    ctx.fillStyle = `rgba(255,240,80,${alpha})`;
    ctx.beginPath();
    ctx.moveTo(x+w/2, y+h*0.78);
    ctx.lineTo(x+w/2-7, y+h*0.86);
    ctx.lineTo(x+w/2+7, y+h*0.86);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = `rgba(180,140,255,${alpha*0.85})`;
    ctx.font = `600 ${Math.round(h*0.085)}px ui-monospace,monospace`;
    ctx.textAlign='left';
    ctx.fillText('MAP · NAV', x+w*0.04, y+h*0.10);
    const items = [['DTG','1142 NM'],['ETE','02:24'],['ETA','14:38Z'],['GS','512 KT']];
    items.forEach(([l,v],i)=>{
      const ry = y+h*0.96-i*h*0.06;
      ctx.fillStyle = `rgba(180,140,255,${alpha*0.6})`;
      ctx.font = `${Math.round(h*0.058)}px ui-monospace,monospace`;
      ctx.textAlign='left'; ctx.fillText(l, x+w*0.04, ry);
      ctx.fillStyle = `rgba(220,210,255,${alpha})`;
      ctx.textAlign='right'; ctx.fillText(v, x+w*0.55, ry);
    });
    ctx.restore();
  }

  function drawEICAS(ctx, sc, t, alpha){
    const {x, y, w, h} = sc;
    ctx.save();
    ctx.beginPath(); ctx.rect(x,y,w,h); ctx.clip();
    ctx.fillStyle = `rgba(2,4,10,${alpha})`;
    ctx.fillRect(x,y,w,h);
    ctx.fillStyle = `rgba(80,220,160,${alpha*0.9})`;
    ctx.font = `600 ${Math.round(h*0.085)}px ui-monospace,monospace`;
    ctx.textAlign='left';
    ctx.fillText('EICAS', x+w*0.04, y+h*0.10);
    [0,1].forEach(i=>{
      const cx = x + w*(0.30 + i*0.40);
      const cy = y + h*0.42;
      const r = h*0.20;
      const n1 = 92.4 + Math.sin(t*0.35 + i)*1.3;
      ctx.strokeStyle = `rgba(40,70,90,${alpha*0.9})`;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(cx, cy, r, Math.PI*0.75, Math.PI*2.25);
      ctx.stroke();
      ctx.strokeStyle = `rgba(80,220,160,${alpha})`;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(cx, cy, r, Math.PI*0.75, Math.PI*0.75 + (n1/100)*Math.PI*1.5);
      ctx.stroke();
      ctx.fillStyle = `rgba(255,255,255,${alpha})`;
      ctx.font = `700 ${Math.round(h*0.12)}px ui-monospace,monospace`;
      ctx.textAlign='center';
      ctx.fillText(n1.toFixed(1), cx, cy+3);
      ctx.fillStyle = `rgba(80,220,160,${alpha*0.7})`;
      ctx.font = `${Math.round(h*0.065)}px ui-monospace,monospace`;
      ctx.fillText('N1 ENG '+(i+1), cx, cy+r+h*0.06);
    });
    const rows = [
      ['ITT',  '742°C', '255,200,40'],
      ['FF',   '2950 lb/h', '0,200,255'],
      ['OIL',  '74 PSI', '80,220,160'],
      ['FUEL', '14 200 lb', '0,200,255'],
    ];
    rows.forEach(([l,v,c],i)=>{
      const ry = y + h*0.75 + (i%2)*h*0.11;
      const col = i<2 ? 0 : 1;
      const lx = x + w*(0.10 + col*0.48);
      ctx.fillStyle = `rgba(${c},${alpha*0.6})`;
      ctx.font = `${Math.round(h*0.062)}px ui-monospace,monospace`;
      ctx.textAlign='left'; ctx.fillText(l, lx, ry);
      ctx.fillStyle = `rgba(${c},${alpha*0.95})`;
      ctx.textAlign='right'; ctx.fillText(v, lx+w*0.35, ry);
    });
    ctx.restore();
  }

  // ───────── HUD HOLOGRAM PROJECTION on windscreen ─────────
  function drawHUD(ctx, x, y, w, h, t, alpha){
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.strokeStyle = `rgba(0,255,210,${alpha*0.55})`;
    ctx.lineWidth = 1.1;
    // central reticle
    const cx = x + w/2, cy = y + h*0.45;
    const r = h*0.07;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI*2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx-r*1.4, cy); ctx.lineTo(cx-r*0.5, cy);
    ctx.moveTo(cx+r*0.5, cy); ctx.lineTo(cx+r*1.4, cy);
    ctx.moveTo(cx, cy-r*1.4); ctx.lineTo(cx, cy-r*0.5);
    ctx.stroke();
    // pitch ladder
    for(let i=-3;i<=3;i++){
      if(i===0) continue;
      const ly = cy + i*r*0.9;
      const ll = r*1.6 - Math.abs(i)*r*0.18;
      ctx.beginPath();
      ctx.moveTo(cx-ll, ly); ctx.lineTo(cx-ll*0.6, ly);
      ctx.moveTo(cx+ll*0.6, ly); ctx.lineTo(cx+ll, ly);
      ctx.stroke();
    }
    // speed tape (left)
    ctx.font = `500 ${Math.round(h*0.020)}px ui-monospace,monospace`;
    ctx.textAlign='left';
    ctx.strokeRect(x+w*0.08, cy-h*0.10, w*0.05, h*0.20);
    ctx.fillStyle = `rgba(0,255,210,${alpha*0.85})`;
    ctx.fillText('482', x+w*0.085, cy+3);
    // alt tape (right)
    ctx.strokeRect(x+w*0.87, cy-h*0.10, w*0.05, h*0.20);
    ctx.fillText('41 000', x+w*0.872, cy+3);
    // top text — FlightDesk brand, split around the central pillar
    ctx.fillStyle = `rgba(0,255,210,${alpha*0.9})`;
    ctx.font = `700 ${Math.round(h*0.028)}px ui-monospace,monospace`;
    ctx.textAlign='right';
    ctx.fillText('Flight', cx - w*0.012, y+h*0.06);
    ctx.textAlign='left';
    ctx.fillText('Desk', cx + w*0.012, y+h*0.06);
    // bottom waypoint readout
    ctx.fillText('WPT KESLA  ·  DIST 142NM  ·  ETA 14:38Z', cx, y+h*0.90);
    ctx.restore();
  }

  // ───────── MAIN ─────────
  function drawCockpitInterior(ctx, W, H, t, alpha){
    const a = clamp(alpha, 0, 1);

    // base — very dark cabin
    ctx.fillStyle = `rgba(4,6,10,${a})`;
    ctx.fillRect(0, 0, W, H);

    // ───── Geometry of the windscreen (panoramic, wraps slightly) ─────
    const winY = H*0.04, winH = H*0.46;
    const winLeftTop = W*0.08, winRightTop = W*0.92;
    const winLeftBot = W*0.02, winRightBot = W*0.98;

    // === DEEP CABIN CEILING (above windscreen) — dark with subtle LED strip
    const ceilG = ctx.createLinearGradient(0, 0, 0, winY);
    ceilG.addColorStop(0, `rgba(2,3,6,${a})`);
    ceilG.addColorStop(1, `rgba(10,12,18,${a})`);
    ctx.fillStyle = ceilG;
    ctx.fillRect(0, 0, W, winY);
    // ceiling LED strip (cyan)
    const ledY = winY*0.4;
    const ledG = ctx.createLinearGradient(W*0.1, ledY, W*0.9, ledY);
    ledG.addColorStop(0, `rgba(80,220,255,0)`);
    ledG.addColorStop(0.5, `rgba(80,220,255,${a*0.45})`);
    ledG.addColorStop(1, `rgba(80,220,255,0)`);
    ctx.fillStyle = ledG;
    ctx.fillRect(W*0.10, ledY-0.6, W*0.80, 1.2);

    // === WINDSCREEN — clipped panoramic view
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(winLeftBot, winY+winH);
    ctx.lineTo(winLeftTop, winY+H*0.005);
    ctx.bezierCurveTo(W*0.30, winY-H*0.02, W*0.70, winY-H*0.02, winRightTop, winY+H*0.005);
    ctx.lineTo(winRightBot, winY+winH);
    ctx.closePath();
    ctx.clip();
    drawWindowView(ctx, 0, 0, W, H*0.85, t, a);
    // HUD hologram (only inside windscreen clip)
    drawHUD(ctx, 0, 0, W, H*0.85, t, a);
    ctx.restore();

    // windscreen rim — chrome with subtle LED edge glow
    ctx.strokeStyle = `rgba(180,200,225,${a*0.55})`;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(winLeftBot, winY+winH);
    ctx.lineTo(winLeftTop, winY+H*0.005);
    ctx.bezierCurveTo(W*0.30, winY-H*0.02, W*0.70, winY-H*0.02, winRightTop, winY+H*0.005);
    ctx.lineTo(winRightBot, winY+winH);
    ctx.stroke();
    // inner cyan LED edge
    ctx.strokeStyle = `rgba(60,200,255,${a*0.30})`;
    ctx.lineWidth = 0.7;
    ctx.stroke();

    // === A-pillars (anguleux, dark carbon)
    const postG = ctx.createLinearGradient(0,0,W*0.08,0);
    postG.addColorStop(0, `rgba(12,14,20,${a})`);
    postG.addColorStop(1, `rgba(28,32,42,${a})`);
    ctx.fillStyle = postG;
    ctx.beginPath();
    ctx.moveTo(0,0); ctx.lineTo(winLeftTop, winY+H*0.005);
    ctx.lineTo(winLeftBot, winY+winH);
    ctx.lineTo(0, winY+winH+H*0.04);
    ctx.closePath(); ctx.fill();
    const postG2 = ctx.createLinearGradient(W*0.92,0,W,0);
    postG2.addColorStop(0, `rgba(28,32,42,${a})`);
    postG2.addColorStop(1, `rgba(12,14,20,${a})`);
    ctx.fillStyle = postG2;
    ctx.beginPath();
    ctx.moveTo(W,0); ctx.lineTo(winRightTop, winY+H*0.005);
    ctx.lineTo(winRightBot, winY+winH);
    ctx.lineTo(W, winY+winH+H*0.04);
    ctx.closePath(); ctx.fill();

    // central thin pillar with embedded LED
    ctx.fillStyle = `rgba(14,16,22,${a*0.95})`;
    const cpW = W*0.006;
    ctx.fillRect(W/2-cpW, winY+H*0.005, cpW*2, winH-H*0.005);
    ctx.fillStyle = `rgba(60,200,255,${a*0.6})`;
    ctx.fillRect(W/2-0.4, winY+H*0.005, 0.8, winH-H*0.005);

    // === Curved glareshield (top hood of dashboard)
    const ghY = winY + winH;
    const gsG = ctx.createLinearGradient(0, ghY-H*0.03, 0, ghY+H*0.04);
    gsG.addColorStop(0, `rgba(4,5,9,0)`);
    gsG.addColorStop(0.4, `rgba(10,12,18,${a*0.85})`);
    gsG.addColorStop(1, `rgba(16,18,24,${a})`);
    ctx.fillStyle = gsG;
    ctx.beginPath();
    ctx.moveTo(0, ghY-H*0.005);
    ctx.bezierCurveTo(W*0.3, ghY+H*0.022, W*0.7, ghY+H*0.022, W, ghY-H*0.005);
    ctx.lineTo(W, ghY+H*0.045);
    ctx.lineTo(0, ghY+H*0.045);
    ctx.closePath();
    ctx.fill();
    // glareshield front edge LED ambient strip (warm white)
    ctx.fillStyle = `rgba(255,235,200,${a*0.30})`;
    ctx.beginPath();
    ctx.moveTo(0, ghY+H*0.030);
    ctx.bezierCurveTo(W*0.3, ghY+H*0.040, W*0.7, ghY+H*0.040, W, ghY+H*0.030);
    ctx.lineTo(W, ghY+H*0.034);
    ctx.bezierCurveTo(W*0.7, ghY+H*0.044, W*0.3, ghY+H*0.044, 0, ghY+H*0.034);
    ctx.closePath();
    ctx.fill();

    // === Dashboard body — curved, glass-panel front
    const dashY = ghY + H*0.045;
    const dashG = ctx.createLinearGradient(0, dashY, 0, H);
    dashG.addColorStop(0,    `rgba(18,20,28,${a})`);
    dashG.addColorStop(0.20, `rgba(22,24,32,${a})`);
    dashG.addColorStop(1,    `rgba(4,5,9,${a})`);
    ctx.fillStyle = dashG;
    ctx.fillRect(0, dashY, W, H);

    // subtle horizontal seam — dashboard surface
    ctx.strokeStyle = `rgba(80,90,110,${a*0.20})`;
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(0, dashY+H*0.005);
    ctx.bezierCurveTo(W*0.3, dashY+H*0.015, W*0.7, dashY+H*0.015, W, dashY+H*0.005);
    ctx.stroke();

    // === Glass screens — curved across dash, single continuous glass strip
    const sY = dashY + H*0.020;
    const sH = H*0.22;
    const gap = W*0.010;
    const sW = (W - gap*4) / 3;
    const screens = [
      {x: gap,            y: sY, w: sW, h: sH, type:'pfd', c:[120,190,255], label:'Module · 01'},
      {x: gap*2+sW,       y: sY, w: sW, h: sH, type:'mfd', c:[180,140,255], label:'FlightDesk · Agent IA'},
      {x: gap*3+sW*2,     y: sY, w: sW, h: sH, type:'eicas', c:[80,220,160], label:'Module · 02'}
    ];
    // shared glass bezel behind all three
    ctx.fillStyle = `rgba(2,3,7,${a})`;
    ctx.beginPath();
    if(ctx.roundRect) ctx.roundRect(gap-6, sY-6, W-gap*2+12, sH+12, 8);
    else ctx.rect(gap-6, sY-6, W-gap*2+12, sH+12);
    ctx.fill();
    ctx.strokeStyle = `rgba(70,90,120,${a*0.5})`;
    ctx.lineWidth = 1.1;
    ctx.stroke();
    // thin cyan edge highlight on top of the glass strip
    ctx.strokeStyle = `rgba(80,200,255,${a*0.45})`;
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(gap-4, sY-3);
    ctx.lineTo(W-gap-2, sY-3);
    ctx.stroke();

    screens.forEach(s=>{
      const [r,g,b] = s.c;
      ctx.fillStyle = `rgba(2,4,10,${a*0.98})`;
      ctx.fillRect(s.x, s.y, s.w, s.h);
      ctx.fillStyle = `rgba(${r},${g},${b},${a*0.08})`;
      ctx.fillRect(s.x, s.y, s.w, s.h*0.10);
      ctx.fillStyle = `rgba(${r},${g},${b},${a*0.9})`;
      ctx.font = `600 ${Math.round(s.h*0.075)}px ui-monospace,monospace`;
      ctx.textAlign='left';
      ctx.fillText(s.label, s.x+8, s.y+s.h*0.078);
      ctx.textAlign='right';
      ctx.fillStyle = `rgba(${r},${g},${b},${a*0.6})`;
      ctx.fillText('14:27Z', s.x+s.w-8, s.y+s.h*0.078);
      ctx.save();
      ctx.beginPath(); ctx.rect(s.x, s.y+s.h*0.11, s.w, s.h*0.89); ctx.clip();
      const sc2 = {x:s.x, y:s.y+s.h*0.11, w:s.w, h:s.h*0.89};
      if(s.type==='pfd') drawPFD(ctx, sc2, t, a);
      if(s.type==='mfd') drawMFD(ctx, sc2, t, a);
      if(s.type==='eicas') drawEICAS(ctx, sc2, t, a);
      ctx.restore();
      // glass sheen
      const gr = ctx.createLinearGradient(s.x, s.y, s.x+s.w, s.y+s.h);
      gr.addColorStop(0, `rgba(255,255,255,${a*0.05})`);
      gr.addColorStop(0.3, 'rgba(255,255,255,0)');
      ctx.fillStyle = gr;
      ctx.fillRect(s.x, s.y, s.w, s.h);
    });

    // === Lower dashboard — Capacitive touch row & controls
    const lowY = sY + sH + H*0.012;
    // touch row background
    ctx.fillStyle = `rgba(8,10,16,${a*0.95})`;
    ctx.fillRect(0, lowY, W, H*0.045);
    // touch buttons (cyan glow)
    for(let i=0;i<12;i++){
      const tx = W*0.06 + i*W*0.075;
      const tw = W*0.055;
      const th = H*0.025;
      const ty = lowY+H*0.010;
      ctx.fillStyle = `rgba(20,28,40,${a})`;
      if(ctx.roundRect){ ctx.beginPath(); ctx.roundRect(tx, ty, tw, th, 3); ctx.fill(); }
      else ctx.fillRect(tx, ty, tw, th);
      // accent line
      ctx.fillStyle = `rgba(60,200,255,${a*(0.30 + 0.30*Math.sin(t*1.7+i))})`;
      ctx.fillRect(tx+2, ty+th-1.5, tw-4, 1);
      // label
      ctx.fillStyle = `rgba(180,210,235,${a*0.65})`;
      ctx.font = `500 ${Math.round(H*0.013)}px ui-monospace,monospace`;
      ctx.textAlign='center';
      const labels = ['AP','A/T','FD','LOC','APP','VNAV','HDG','SPD','ALT','VS','XPDR','FMS'];
      ctx.fillText(labels[i]||'', tx+tw/2, ty+th*0.62);
    }

    // === Center pedestal with throttles + holographic top
    const pedTopY = lowY + H*0.050;
    const pX = W/2;
    const pedG = ctx.createLinearGradient(pX-W*0.07, pedTopY, pX+W*0.07, pedTopY);
    pedG.addColorStop(0, `rgba(8,10,16,${a})`);
    pedG.addColorStop(0.5, `rgba(20,24,34,${a})`);
    pedG.addColorStop(1, `rgba(8,10,16,${a})`);
    ctx.fillStyle = pedG;
    ctx.beginPath();
    ctx.moveTo(pX-W*0.060, pedTopY);
    ctx.bezierCurveTo(pX-W*0.075, pedTopY+H*0.10, pX-W*0.085, H*0.85, pX-W*0.082, H);
    ctx.lineTo(pX+W*0.082, H);
    ctx.bezierCurveTo(pX+W*0.085, H*0.85, pX+W*0.075, pedTopY+H*0.10, pX+W*0.060, pedTopY);
    ctx.closePath();
    ctx.fill();
    // pedestal LED outline (cyan, accent)
    ctx.strokeStyle = `rgba(60,200,255,${a*0.45})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pX-W*0.060, pedTopY);
    ctx.bezierCurveTo(pX-W*0.075, pedTopY+H*0.10, pX-W*0.085, H*0.85, pX-W*0.082, H);
    ctx.moveTo(pX+W*0.060, pedTopY);
    ctx.bezierCurveTo(pX+W*0.075, pedTopY+H*0.10, pX+W*0.085, H*0.85, pX+W*0.082, H);
    ctx.stroke();

    // throttle quadrant
    [-1,1].forEach(side=>{
      const tx = pX + side*W*0.025;
      const ty = pedTopY + H*0.025;
      ctx.fillStyle = `rgba(30,36,48,${a})`;
      ctx.beginPath();
      if(ctx.roundRect) ctx.roundRect(tx-5, ty, 10, H*0.09, 3);
      else ctx.rect(tx-5, ty, 10, H*0.09);
      ctx.fill();
      // metallic chrome knob top
      const tg = ctx.createRadialGradient(tx, ty-3, 0, tx, ty-3, 11);
      tg.addColorStop(0,    `rgba(220,228,236,${a})`);
      tg.addColorStop(0.45, `rgba(150,160,176,${a})`);
      tg.addColorStop(1,    `rgba(40,46,58,${a})`);
      ctx.fillStyle = tg;
      ctx.beginPath();
      ctx.ellipse(tx, ty, 7, 5, 0, 0, Math.PI*2); ctx.fill();
      // LED ring
      ctx.strokeStyle = `rgba(60,220,255,${a*0.7})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(tx, ty, 7.5, 5.5, 0, 0, Math.PI*2); ctx.stroke();
    });

    // small holographic projection above pedestal (subtle cyan glow)
    const holoG = ctx.createRadialGradient(pX, pedTopY-H*0.005, 0, pX, pedTopY-H*0.005, W*0.05);
    holoG.addColorStop(0, `rgba(60,220,255,${a*0.25})`);
    holoG.addColorStop(1, `rgba(60,220,255,0)`);
    ctx.fillStyle = holoG;
    ctx.fillRect(pX-W*0.08, pedTopY-H*0.04, W*0.16, H*0.08);

    // radio LCD on pedestal
    ctx.fillStyle = `rgba(2,4,8,${a})`;
    ctx.fillRect(pX-W*0.030, pedTopY+H*0.135, W*0.060, H*0.035);
    ctx.fillStyle = `rgba(60,220,255,${a*0.95})`;
    ctx.font = `600 ${Math.round(H*0.022)}px ui-monospace,monospace`;
    ctx.textAlign='center';
    ctx.fillText('118.500', pX, pedTopY+H*0.160);

    // === SIDE-STICK CONTROLLERS (modern jets use them instead of yoke)
    // Two small black grips: one between left seat & pedestal, one between
    // pedestal & right seat. They project up from below.
    function drawSideStick(ctx, sx, sy){
      // base
      ctx.fillStyle = `rgba(14,16,22,${a})`;
      ctx.beginPath();
      if(ctx.roundRect) ctx.roundRect(sx-W*0.025, sy, W*0.050, H*0.03, 4);
      else ctx.rect(sx-W*0.025, sy, W*0.050, H*0.03);
      ctx.fill();
      // shaft
      const sg = ctx.createLinearGradient(sx-W*0.012, sy, sx+W*0.012, sy);
      sg.addColorStop(0, '#1a1d28');
      sg.addColorStop(0.5, '#2a2d3a');
      sg.addColorStop(1, '#1a1d28');
      ctx.fillStyle = sg;
      ctx.fillRect(sx-W*0.012, sy-H*0.04, W*0.024, H*0.04);
      // grip (curved top)
      const gg = ctx.createLinearGradient(sx-W*0.022, sy-H*0.08, sx+W*0.022, sy-H*0.04);
      gg.addColorStop(0, '#0a0b10');
      gg.addColorStop(0.5, '#1f2230');
      gg.addColorStop(1, '#0a0b10');
      ctx.fillStyle = gg;
      ctx.beginPath();
      ctx.moveTo(sx-W*0.022, sy-H*0.04);
      ctx.bezierCurveTo(sx-W*0.025, sy-H*0.10, sx+W*0.025, sy-H*0.10, sx+W*0.022, sy-H*0.04);
      ctx.closePath();
      ctx.fill();
      // trigger button (red)
      ctx.fillStyle = `rgba(180,50,50,${a})`;
      ctx.beginPath();
      ctx.arc(sx, sy-H*0.07, W*0.005, 0, Math.PI*2);
      ctx.fill();
    }
    drawSideStick(ctx, W*0.34, pedTopY+H*0.08);
    drawSideStick(ctx, W*0.66, pedTopY+H*0.08);

    // === COCKPIT FLOOR HINT (very dark, with subtle LED foot-well lighting)
    const floorY = H*0.92;
    const floorG = ctx.createLinearGradient(0, floorY, 0, H);
    floorG.addColorStop(0, `rgba(4,5,9,${a})`);
    floorG.addColorStop(1, `rgba(0,0,0,${a})`);
    ctx.fillStyle = floorG;
    ctx.fillRect(0, floorY, W, H-floorY);
    // LED foot-well glow strip
    ctx.fillStyle = `rgba(60,200,255,${a*0.15})`;
    ctx.fillRect(W*0.10, H*0.95, W*0.80, 1);

    // === THE TWO SEATS — REAR POV, only upper backs visible
    // Smaller, narrower, pushed to the very corners so the dashboard reads clearly.
    // We only see the headrest + a small slice of the shoulders — like sitting at the back of the cabin.
    const seatW = W*0.24;
    const seatH = H*0.36;
    // baseY = top of the seat back. Headrest peaks ~H*0.55, body extends off-screen.
    const seatBaseY = H*0.78;
    drawSeatBack(ctx, W*0.13, seatBaseY, seatW, seatH, a, -1, '90,200,255', 'Flight');
    drawSeatBack(ctx, W*0.87, seatBaseY, seatW, seatH, a, +1, '90,200,255', 'Desk');

    // === Warm light spill from windscreen onto top of dashboard
    const wlight = ctx.createLinearGradient(0, winY+winH*0.55, 0, dashY+H*0.06);
    wlight.addColorStop(0, `rgba(255,225,180,${a*0.08})`);
    wlight.addColorStop(1, 'rgba(255,225,180,0)');
    ctx.fillStyle = wlight;
    ctx.fillRect(0, winY+winH*0.55, W, H*0.14);

    // === Cinematic vignette (heavy on edges)
    const vig = ctx.createRadialGradient(W/2, H*0.42, H*0.30, W/2, H*0.42, H*1.05);
    vig.addColorStop(0, 'rgba(0,0,0,0)');
    vig.addColorStop(0.5, 'rgba(0,0,0,0)');
    vig.addColorStop(1, `rgba(0,0,0,${a*0.92})`);
    ctx.fillStyle = vig;
    ctx.fillRect(0, 0, W, H);
  }

  return {drawCockpitInterior};
})();
